package m801.algorithms;

import java.util.ArrayList;
import java.util.List;

import m801.business_objects.Attribute;
import m801.business_objects.Constraint;
import m801.business_objects.Entity;
import m801.business_objects.Relationship;

public class EntityLinkageInformation 
{
	//This is the constructor
	public EntityLinkageInformation()
	{
		_constraints   = new ArrayList<Constraint>();
		_relationships = new ArrayList<Relationship>();
		_entity = new Entity();
	}
	
	//This method clobnes the EntityLinkageInformation object
	public EntityLinkageInformation Clone()
	{
		EntityLinkageInformation eli = new EntityLinkageInformation();
		eli.setEntity(eli.getEntityClone());
		eli.setRelationship(getRelationshipsClone());
		eli.setConstraint(getConstraintsClone());
		
		return eli;
	}
		
	//This method gets the entity in the EntityLinkageInformation object
	public Entity getEntity()
	{
		return _entity;
	}
	
	//This method clones the entity from the EntityLinkageInformation object
	public Entity getEntityClone()
	{
		Entity entity = new Entity();
		entity.setName(_entity.getName());
		for(Attribute attribute: _entity.getAttributes())
		{
			entity.addAttribute(attribute);
		}
		
		return entity;
	}
	
	//This method adds a relation to the EntityLinkageInformation object
	public void addRelationship(Relationship relationship)
	{
		_relationships.add(relationship);
	}
	
	//This method adds a constraint to the EntityLinkageInformation object
	public void addConstrainst (Constraint constraint)
	{
		_constraints.add(constraint);
		
	}
	
	//This method sets an entity to the EntityLinkageInformation object
	public void setEntity(Entity entity)
	{
		_entity = entity;
	}
	
	//This method set a list of relationships to the EntityLinkageInformation object
	public void setRelationship(List<Relationship> relationships)
	{
		_relationships = relationships;
	}
	
	//This method sets a list of constraints to the EntityLinkageInformation object
	public void setConstraint(List<Constraint> constraints)
	{
		_constraints = constraints;
	}
	
	//This method gets the list of relationships from the EntityLinkageInformation object
	public List<Relationship> getRelationships()
	{
		return _relationships;
	}
	
	//This method gets the list of constraints from the EntityLinkageInformation object
	public List<Constraint> getConstraints()
	{
		return _constraints;
	}
	
	//This method clones the list of relationships from the EntityLinkageInformation object
	public List<Relationship> getRelationshipsClone()
	{
		List<Relationship> relationships = new ArrayList<Relationship>();
		for (Relationship relationship:_relationships)
		{
			relationships.add(relationship);
		}
		
		return relationships;
	}
	
	//This method clones the list of constraints from the EntityLinkageInformation object
	public List<Constraint> getConstraintsClone()
	{
		List<Constraint> constraints = new ArrayList<Constraint>();
		for (Constraint constraint:_constraints)
		{
			constraints.add(constraint);
		}
		
		return constraints;
	}
	
	private List<Relationship> _relationships;
	private List<Constraint> _constraints;
	private Entity _entity;
}