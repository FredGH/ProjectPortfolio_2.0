package m801.algorithms;

import java.util.List;
import java.util.ArrayList;

public class Element 
{
	//This is the constructor
	public Element()
	{
		_partitions = new ArrayList<Partition>();
	}

	//This method gets the paritions from an element object
	public List<Partition> getPartitions()
	{
		return _partitions;
	}
	
	//This method adds a parition to an element object
	public void addPartition(Partition partition)
	{
		if (_partitions ==null)
			_partitions =  new ArrayList<Partition>();

		_partitions.add(partition);
	}
		
	//This method removes a parition from an element object, given an index
	public void removePartition(int index)
	{
		_partitions.remove(index);
	}
	
	private List<Partition> _partitions;
}