package m801.data_source_adapater.interfaces;

public interface IDataSourceAdapter 
{
	public Object GetDataSource();

}
