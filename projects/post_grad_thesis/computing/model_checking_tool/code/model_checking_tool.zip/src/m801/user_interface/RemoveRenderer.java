package m801.user_interface;

import java.awt.Component;
import javax.swing.JComboBox;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;

import m801.utils.Globals;

//This class displays the value in the JComboBox
public class RemoveRenderer extends JComboBox implements TableCellRenderer
{
	//This is the constructor
	public RemoveRenderer()
	{
		super();
		addItem(Globals.YES);
		addItem(Globals.NO);
				
		super.setFont(Globals.DEFAULTFONT);
	}
	
	//Overrides getTableCellRendererComponent
	public Component getTableCellRendererComponent(	JTable table, 
													Object value, 
													boolean isSelected, 
													boolean hasFocus, 
													int row, 
													int column)
	{
		setForeground(table.getSelectionBackground());
		super.setBackground(table.getSelectionBackground());
	
		boolean isYes = ((Boolean)value).booleanValue();
		setSelectedIndex(isYes ? 0 : 1);
		
		return this;
	}
	
	//this is enforced by the comopiler... I have selected a value, but could be any long
	static final long serialVersionUID = 131420; 
}
