package m801.business_objects;

import m801.utils.Globals;

//This class represents the relationship end object
public class RelationshipEnd 
{
	//The constructor
	public RelationshipEnd()
	{
		_entityName = "";
		_direction ="";
		_optionality= "0";
		_degree= "0";	
	}
	
	//Set then entity name
	public void setEntityName(String entityName)
	{
		_entityName = entityName;
	}
	
	//Get the entity name
	public String getEntityName()
	{
		return _entityName;
	}
	
	//Set the direction
	public void setDirection(String direction)
	{
		_direction = direction;
	}
	
	//Get the direction
	public String getDirection()
	{
		return _direction;
	}
	
	//Set the optionality
	public void setOptionality(String optionality)
	{
		_optionality = optionality;
	}
	
	//Get the optionality
	public String getOptionalityToScalar()
	{
		return _optionality.toString();
	}
	
	//Get the optionality as a boolean
	public Boolean getOptionalityToBool()
	{
		return Globals.ToBoolean(getOptionalityToScalar());
	}
	
	//Get the optionality as the enum
	public Enum.Optionality getOptionality()
	{
		if (_optionality == "0")
			return Enum.Optionality.OPTIONAL;
		else
			return Enum.Optionality.MANDATORY;
	}
	
	//Set the degree
	public void setDegree(String degree)
	{
		_degree = degree;
	}
	
	//Get the degree
	public String getDegreeToScalar()
	{
		return _degree.toString();
	}
	
	//Get the degree as a boolean
	public Boolean getDegreeToBool()
	{
		return Globals.ToBoolean(getDegreeToScalar());
	}
	
	////Get the degree as the enum
	public Enum.Degree getDegree()
	{
		if (_degree == "0")
			return Enum.Degree.MANY;
		else
			return Enum.Degree.ONE;
	}

	private String _entityName;
	private String _direction;
	private String _optionality;
	private String _degree;	
}
