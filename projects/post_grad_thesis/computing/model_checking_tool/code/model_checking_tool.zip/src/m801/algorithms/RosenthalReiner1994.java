package m801.algorithms;

import java.util.ArrayList;
import java.util.List;

import m801.algorithms.interfaces.IGraph;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.utils.SingleLinkedList;



//This is the RosenthalReiner1994 algorithm that finds potential redundant relationship in an ERD
//based on the attribute names
public class RosenthalReiner1994 extends GraphOperations 
{
	public RosenthalReiner1994(){}
	
	//This is an override of the base class.
	protected ElementGraph addEdgeToGraph(	int nVertices,
											IGraph booleanGraph, 
											IGraph elementGraph,
											ElementGraph nDegreeGraph,
											ElementGraph currentGraph,
											EntityRelationshipDiagram erd, 
											int currentOrder)
	{

		if (currentOrder <= 2)
		{
			for (int i=0; i< nVertices; i++)
			{
				List<Partition> partitions = new ArrayList<Partition>(); 
				Element element =  new Element();
				
				for(int k=0; k<nVertices; k++)
				{
					//create an element
					element = createElement(	erd, 
												booleanGraph, 
												elementGraph,
												currentGraph,	
												element,
												partitions,	
												i, i, k,
												currentOrder);	
				}
				
				//add the element to the graph
				addEdgeToGraph(nDegreeGraph,i,i, element);
			}
		}

		return nDegreeGraph;
	}
	
	//This is an override of the base class.
	//This algorithm does not implement a signature.
	//This method is not implemented, it returns a default value
	protected Signature createSignature(	EntityRelationshipDiagram erd,
											Entity fromEntity, 
											Entity toEntity,
											SingleLinkedList entitySingleLinkedList)
	{
		//TO IMPLEMENT...
		return null;
	}
	
	//This method indicates whether the realtionships between two entites in the graph is unwanted, i.e.
	//1. it displays a recursive relatonship when this should not be the case in the initial bool matrix.
	//2. it displays a number of relationships between two entites that is greater than the one described in the inital bool matrix
	protected  boolean isUnwantedPartition (	Entity entityFrom, 
														Entity entityTo, 	
														EntityRelationshipDiagram erd,
														BooleanGraph booleanGraph,
														Partition partition)
	{
		//TO IMPLEMENT...
		return false;
	}
	
	//Get the list of potential redundant relationships
	//This method is not implemented, it returns a default value
	public List<PotentialRedundantRelationship> getPotentialRedundantRelationships(	EntityRelationshipDiagram erd, 
																					BooleanGraph booleanGraph, 
																					ElementGraph elementGraph)
	{
		//TO IMPLEMENT
		return null;  
	}
	
	// This method removes partitions
	//This method is not implemented, it returns a default value
	public  ElementGraph removePartition(ElementGraph elementGraph, String[] pathsToRemove)
	{
		//TO IMPLEMENT
		return null;
		
	}
	
	// This method remove unwanted partitions
	//This method is not implemented, it returns a default value
	public  ElementGraph removeUnwantedPartition(	EntityRelationshipDiagram erd,
													BooleanGraph booleanGraph, 
													ElementGraph elementGraph)
	{
		//TO IMPLEMENT
		return null;
	}
}