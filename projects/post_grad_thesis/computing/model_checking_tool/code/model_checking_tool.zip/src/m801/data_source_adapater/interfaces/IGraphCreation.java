package m801.data_source_adapater.interfaces;

import m801.algorithms.BooleanGraph;
import m801.algorithms.ElementGraph;
import m801.business_objects.EntityRelationshipDiagram;

public interface IGraphCreation 
{
	//Create the in memory ERD
	public EntityRelationshipDiagram createERD(String algoType);
	
	//Create the initial boolean graph given an algoType and an ERD
	public BooleanGraph createInitialGraph(String algoType, EntityRelationshipDiagram erd);
	
	//Remove a partition given the parameter list
	public ElementGraph RemovePartition (String algoType, ElementGraph elementGraph, String[] pathsToRemove);

}
