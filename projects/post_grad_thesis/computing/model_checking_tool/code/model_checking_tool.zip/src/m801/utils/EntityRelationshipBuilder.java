package m801.utils;

import java.util.List;

import m801.business_objects.Attribute;
import m801.business_objects.Constraint;
import m801.business_objects.ConstraintEnd;
import m801.business_objects.ConstraintEndAttribute;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;
import m801.business_objects.RelationshipEnd;

//This class enable the creation of an in memory Relationship diagram
public class EntityRelationshipBuilder 
{
	//This method creates an entity relationship diagram given the list of parameters
	public EntityRelationshipDiagram CreateEntityRelationshipDiagram(	
																	String name, 
																	String modelType, 
																	List<Entity>  entities,
																	List<Relationship> relationships,
																	List<Constraint> constraints)
	{
		EntityRelationshipDiagram erd = new EntityRelationshipDiagram();
		erd.setName(name);
		erd.setType(modelType);
		
		for(Entity entity: entities)
			erd.addEntity(entity);
		for(Relationship relationship: relationships)
			erd.addRelationship(relationship);
		for(Constraint constraint: constraints)
			erd.addConstraints(constraint);
		
		return erd;	
	}
	
	//This method creates an entity
	public Entity CreateEntity(String name, List<Attribute> attributes)
	{
		Entity entity = new Entity();
		entity.setName(name);
		
		for(Attribute attribute:attributes)
			entity.addAttribute(attribute);
		
		return entity;
	}
	
	//This method creates an attribute
	public Attribute CreateAttribute(String name, String type, String primaryKey, String foreignKey)
	{
		Attribute attribute = new Attribute();
		attribute.setName(name);
		attribute.setType(type);
		attribute.setPrimaryKey(primaryKey);
		attribute.setForeignKey(foreignKey);
		
		return attribute;
	}
	
	//This method creates a relationship
	public Relationship CreateRelationship(String name, RelationshipEnd from, RelationshipEnd to)
	{
		Relationship relationship = new Relationship();
		relationship.setName(name);
		relationship.setFrom(from);
		relationship.setTo(to);
		
		return relationship;
	}
	
	//This method creates a RelationshipEnd
	public RelationshipEnd CreateRelationshipEnd(String entityName, String direction,  String optionality, String degree)
	{
		RelationshipEnd relationshipEnd = new RelationshipEnd();
		relationshipEnd.setEntityName(entityName);
		relationshipEnd.setDirection(direction);
		relationshipEnd.setOptionality(optionality);
		relationshipEnd.setDegree(degree);
	
		return relationshipEnd;
	}
	
	//This method creates a constraint
	public Constraint CreateConstraint(ConstraintEnd from, ConstraintEnd to)
	{
		Constraint constraint = new Constraint();
		constraint.setFrom(from);
		constraint.setTo(to);
		
		return constraint;
	}
	
	//This method creates a contraintEnd
	public ConstraintEnd CreateConstraintEnd(String entityName, String direction,  List<ConstraintEndAttribute> constraintEndAttributes)
	{
		ConstraintEnd constraintEnd = new ConstraintEnd();
		constraintEnd.setEntityName(entityName);
		constraintEnd.setDirection(direction);
		constraintEnd.setAttributes(constraintEndAttributes);
	
		return constraintEnd;
	}
	
	//This method create a constraint attribute
	public ConstraintEndAttribute CreateConstraintEndAttribute(String attributeName)
	{
		ConstraintEndAttribute constraintEndAttribute = new ConstraintEndAttribute();
		constraintEndAttribute.setName(attributeName);
	
		return constraintEndAttribute;
	}
}
