package m801.algorithms;

import java.util.List;

import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;
import m801.utils.SingleLinkedList;

//This classs generates the signature for a parition
public class SignatureComposition 
{
	
	//Check whether a signature is equivalent to another
	public static boolean SignatureIsEquivalent(Relationship boolRelationship, Partition partition)
	{
		if (	boolRelationship.getFrom().getOptionalityToBool() 	== partition.getSignature().getLeftOptionality() && 
				boolRelationship.getFrom().getDegreeToBool() 		== partition.getSignature().getLeftCardinality() &&
				boolRelationship.getTo().getOptionalityToBool() 	== partition.getSignature().getRightOptionality() &&
				boolRelationship.getTo().getDegreeToBool() 			== partition.getSignature().getRightCardinality() )
		{
			return true;
		}
		
		return false;
	}

	
	//calculate the signature, based on the list of parmaters
	public static Signature calculate(	EntityRelationshipDiagram erd,
										Entity fromEntity, 
										SingleLinkedList entitySingleLinkedList,
										Entity toEntity) throws Exception
	{
		Entity firstEntity =null, secondEntity = null;
		Signature compSignature = null;
		
		if (entitySingleLinkedList.size() == 0)
		throw new Exception ("There is no path between the two entities:" + fromEntity.getName() + " and " + toEntity.getName() );
		
		for (int i =0; i<entitySingleLinkedList.size(); i++)
		{
			if (i == 0)
			{
				firstEntity = fromEntity; 
				secondEntity = getEntity((EntityLinkageInformation)entitySingleLinkedList.getNode(i));
			}
			else if (i> 0 && i<entitySingleLinkedList.size())
			{
				firstEntity = getEntity((EntityLinkageInformation)entitySingleLinkedList.getNode(i-1)); 
				secondEntity = getEntity((EntityLinkageInformation)entitySingleLinkedList.getNode(i));
			}
			
			compSignature = calculate(erd, firstEntity, secondEntity, compSignature);
		}
		
		//last entity in the list
		Entity lastEntity = getEntity((EntityLinkageInformation)entitySingleLinkedList.getNode(entitySingleLinkedList.size()-1));
		
		compSignature = calculate(erd, lastEntity, toEntity, compSignature);
		
		return compSignature;
	}
	
	//Get a deep copy of an entity
	private static Entity getEntity(EntityLinkageInformation eli)
	{
		return eli.getEntityClone();
	}

	//Calculate the signature
	private static Signature calculate(	EntityRelationshipDiagram erd, 
										Entity fromEntity,
										Entity toEntity, 
										Signature compSignature) throws Exception
	{		
		Relationship relationship =null;
		List<Relationship>  relationships =erd.getRelationships();
		boolean bFound =false;
		Signature signature =null;
		boolean bReverse = false;
		
		for (int i =0; i< relationships.size(); i++)
		{
			relationship = erd.getRelationships().get(i);
			if ( 	relationship.getFrom().getEntityName().equalsIgnoreCase(fromEntity.getName())&&  
					relationship.getTo().getEntityName().equalsIgnoreCase(toEntity.getName()))
			{
				bFound =true;
				break;
			}
			else if (relationship.getTo().getEntityName().equalsIgnoreCase(fromEntity.getName()) &&
					relationship.getFrom().getEntityName().equalsIgnoreCase(toEntity.getName()))
			{
				bReverse =true;
				bFound =true;
				break;
			}
		}
		
		
		if (bFound)
		{
			signature = new Signature();
			if (bReverse)
			{
				signature.setLeftCardinality(relationship.getTo().getDegreeToBool());
				signature.setLeftOptionality(relationship.getTo().getOptionalityToBool());
				signature.setRightOptionality(relationship.getFrom().getOptionalityToBool());
				signature.setRightCardinality(relationship.getFrom().getDegreeToBool());
			}
			else
			{
				signature.setLeftCardinality(relationship.getFrom().getDegreeToBool());
				signature.setLeftOptionality(relationship.getFrom().getOptionalityToBool());
				signature.setRightOptionality(relationship.getTo().getOptionalityToBool());
				signature.setRightCardinality(relationship.getTo().getDegreeToBool());
			}
		}
		else
		throw new Exception ("No relationship is found between the two entities:" + fromEntity.getName() + " and " + toEntity.getName() );

		if (compSignature != null)
			signature = calculate(signature, compSignature);			
		
		return signature;
	}
	
	//Calculate the signature
	private static Signature calculate (Signature signature1, Signature signature2)
	{		
		boolean leftCardinality1= signature1.getLeftCardinality();
		boolean leftCardinality2 = signature2.getLeftCardinality();
		boolean leftCardinality =  leftCardinality1 & leftCardinality2;
		
		boolean leftOptionality1 = signature1.getLeftOptionality();
		boolean leftOptionality2 = signature2.getLeftOptionality();
		boolean leftOptionality =  leftOptionality1 & leftOptionality2;
		
		boolean rightCardinality1= signature1.getRightCardinality();
		boolean rightCardinality2 = signature2.getRightCardinality();
		boolean rightCardinality =  rightCardinality1 & rightCardinality2;
		
		boolean rightOptionality1 = signature1.getRightOptionality();
		boolean rightOptionality2 = signature2.getRightOptionality();
		boolean rightOptionality =  rightOptionality1 & rightOptionality2;
		
		Signature signature = new Signature();
		signature.setLeftCardinality(leftCardinality);
		signature.setLeftOptionality(leftOptionality);
		signature.setRightCardinality(rightCardinality);
		signature.setRightOptionality(rightOptionality);
		
		return signature;
	}
}
