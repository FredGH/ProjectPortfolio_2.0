package m801.algorithms.interfaces;

public interface IGraph 
{
	public int getVerticeSize();
	
	public int getEdgeSize();
	
	public int size();
	
	public Object getElement(int vertice1, int vertice2);
	
}

