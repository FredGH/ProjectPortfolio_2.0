package m801.algorithms;

import java.util.List;

import m801.business_objects.Attribute;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;


//This class extends the ShortCut class
public class HorizontalShortcut extends Shortcut
{
	//This is the constructor
	public HorizontalShortcut(	EntityRelationshipDiagram erd,
								List<Relationship> relationships,
								Entity fromEntity,
								List<Attribute> fromEntityAtttibutesPK,
								List<Attribute> fromEntityAtttibutes,
								Entity midEntity,
								List<Attribute> midEntityAtttibutesPK,
								List<Attribute> midEntityAtttibutes,
								Entity toEntity,	
								List<Attribute> toEntityAtttibutesPK,
								List<Attribute> toEntityAtttibutes)
	{
		super(	erd,
				relationships,
				fromEntity, 
				fromEntityAtttibutesPK,
				fromEntityAtttibutes,
				midEntity,
				midEntityAtttibutesPK,
				midEntityAtttibutes,
				toEntity, 
				toEntityAtttibutesPK, 
				toEntityAtttibutes
			);
	}
	
	//This method check whether the PK attributes of the from entity are shared in the two other entities
	//This method is not implemented, it returns a default value
	protected boolean isAttributeSharedInAllEntities()
	{
		//TO IMPEMENT
		return false;
	}
	
	//This method checks whether there is an inclusion constraint 
	//This method is not implemented, it returns a default value
	protected boolean hasInclusionConstraint()
	{
		//TO IMPEMENT
		return false;
	}
}
