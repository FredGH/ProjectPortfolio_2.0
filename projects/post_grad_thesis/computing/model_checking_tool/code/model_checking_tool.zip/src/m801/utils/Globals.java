package m801.utils;

import java.awt.*;

//This class represents is shared accross different component
public class Globals 
{
	public final static int NOT_FOUND 				= -1;
	public final static String NOT_AVAILABLE 		= "NOT_AVAILABLE";
	public final static String _ENHANCEDBOWERS 		= "ENHANCEDBOWERS";
	public final static String _DUELLASONG			= "DUELLASONG";
	public final static String _ROSENTHALREINER		= "ROSENTHALREINER";
	public final static String _ALLPATHS	 		= "ALL";
	public final static String _INCREMENTALPATHS	= "INCREMENTAL";
	public final static String YES 					= "Yes";
	public final static String NO 					= "No";
	public final static String EMPTY 				= "";
	public final static Font DEFAULTFONT 			= new Font("SansSerif", Font.BOLD, 14);


	//This method checls where an index is valid
	public static void checkIndexValidatity(int index) throws Exception
	{
		if (index == Globals.NOT_FOUND)
		{
			throw new Exception ("the from index is set to -1");
		}
	}
	
	//This method transforms a string bool value into a boolean type.
	public static boolean ToBoolean(String boolValue)
	{
		if (boolValue.equals("1"))
			return true;
		
		return false;
	}
}
