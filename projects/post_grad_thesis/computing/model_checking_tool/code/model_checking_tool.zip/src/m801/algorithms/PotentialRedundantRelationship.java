package m801.algorithms;

import m801.business_objects.Entity;
import m801.business_objects.Relationship;

//This is the Potential Redundant Relationship class
public class PotentialRedundantRelationship 
{
	//Get the partition
	public Partition getPartition()
	{
		return _partition;
	}
	
	//Get the relationship
	public Relationship getRelationship()
	{
		return _relationship;
	}
	
	//Get the entityFrom
	public Entity getFromEntity()
	{
		return _fromEntity;
	}
	
	//Get he entityTo
	public Entity getToEntity()
	{
		return _toEntity;	
	}
	
	//Set the parition
	public void setPartition(Partition partition)
	{
		_partition = partition;
	}
	
	//Set the relationship
	public void setRelationship(Relationship relationship)
	{
		_relationship = relationship;
	}
	
	//Set the from entity
	public void setFromEntity(Entity fromEntity)
	{
		_fromEntity = fromEntity;
	}
	
	//Set the to entity
	public void setToEntity(Entity toEntity)
	{
		_toEntity = toEntity;	
	}
	
	private Relationship _relationship;
	private Partition _partition;
	private Entity _fromEntity;
	private Entity _toEntity;
}
