package m801.model_checking_tool.actions;

import m801.user_interface.Table;

import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.MessageDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IWorkbenchWindow;
import org.eclipse.ui.IWorkbenchWindowActionDelegate;

/**
 * Our sample action implements workbench action delegate.
 * The action proxy will be created by the workbench and
 * shown in the UI. When the user tries to use the action,
 * this delegate will be created and execution will be 
 * delegated to it.
 * @see IWorkbenchWindowActionDelegate
 */
public class DenseERD implements IWorkbenchWindowActionDelegate {
	private IWorkbenchWindow window;
	/**
	 * The constructor.
	 */
	public DenseERD() 
	{
	}

	/**
	 * The action has been activated. The argument of the
	 * method represents the 'real' action sitting
	 * in the workbench UI.
	 * @see IWorkbenchWindowActionDelegate#run
	 */
	public void run(IAction action) 
	{
		m801.utils.PerformanceLogBuilder.clear();
		String path1 = "C:/Documents and Settings/All Users/Start Menu/Programs/a_Thesis/Eclipse/Eclipse SDK/eclipse-SDK-3.3M4-win32/eclipse-SDK-3.3M4-win32/eclipse/MyFiles/MiniCases/ExecTime";
		
		String path = path1 + "/Dense/";

		setTest(path, "TestETA.xml",4);
		setTest(path, "TestETB.xml",9);
		setTest(path, "TestETC.xml",19);
		setTest(path, "TestETD.xml",39);
		setTest(path, "TestETE.xml",79);
		setTest(path, "TestETF.xml",159);
			
		Shell shell = new Shell();
		MessageDialog.openInformation(
			shell,
			"Test Module",
			"Test Complete!");
	}
	
	private void setTest(String path, String testName, int maxOrder)
	{
		Table t = new Table();
		t.AutomatedTestGenerateGraph(path, testName, maxOrder);
	}
	
	/**
	 * Selection in the workbench has been changed. We 
	 * can change the state of the 'real' action here
	 * if we want, but this can only happen after 
	 * the delegate has been created.
	 * @see IWorkbenchWindowActionDelegate#selectionChanged
	 */
	public void selectionChanged(IAction action, ISelection selection) {
	}

	/**
	 * We can use this method to dispose of any system
	 * resources we previously allocated.
	 * @see IWorkbenchWindowActionDelegate#dispose
	 */
	public void dispose() {
	}

	/**
	 * We will cache window object in order to
	 * be able to provide parent shell for the message dialog.
	 * @see IWorkbenchWindowActionDelegate#init
	 */
	public void init(IWorkbenchWindow window) {
		this.window = window;
	}
}