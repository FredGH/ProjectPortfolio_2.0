package m801.user_interface;

import java.awt.*;
import java.awt.event.*;
import java.util.Date;
import java.util.List;
import javax.swing.border.*;
import javax.swing.*;
import javax.swing.table.*;

import m801.algorithms.BooleanGraph;
import m801.algorithms.ElementGraph;
import m801.algorithms.PotentialRedundantRelationship;
import m801.business_objects.EntityRelationshipDiagram;
import m801.data_source_adapter.XmlAdapter;
import m801.utils.Globals;

//This class handles the UI construction
public class Table extends JFrame
{
	//The constructor
	public  Table()
	{
		_erd 			= null;
		_algoCombo 		= null;
		_booleanGraph 	= null;
		_selectedAlgo 	= _noAlgoSelected;
		_xmlAdapter 	= null;
		_currentOrder	= 1;
		_nDegreeGraph   = null; 
		_pane			= null;
		_orderLabel		= null;
		_nextButton		= null;
		_filePathText	= null;
		_filePath		= "";
		_rn 			= null;
		_masterGrid 	= "masterGrid";
	}
	
	//It initialises the table data with the test data 
	public void initialise()
	{
		displaySelectors();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	//It displays the selectors (i.e. comboxes, textbox, etc.) in the UI
	public void displaySelectors()
	{
		this.setTitle("Graph Edges Validator 2008");
		
		_pane = getContentPane();
		_pane.setLayout(new BorderLayout());
		
		//Add other components to the Pane...	
		//define the algo combo
		Object[] oComponents = new Object[5];
		_algoCombo = fillCombo(new String[]{	_selectAlgo, 
												Globals._ENHANCEDBOWERS, 
												Globals._ROSENTHALREINER,
												Globals._DUELLASONG}, 
												_algoCb, 0);
		oComponents[0] = _algoCombo;
		
		
		//define the 'current schema' button
		_filePathText = new JTextField(30);
		_filePathText.setEnabled(true);
		_filePathText.setText("Please provide the test case '.xml' full file path");
		oComponents[1] = _filePathText;
		
		//define the 'current schema' button
		_reloadButton = new JButton();
		_reloadButton.setEnabled(false);
		_reloadButton.setText(_reloadLabel);
		oComponents[2] = _reloadButton;
		
		//define the 'next' button
		_nextButton = new JButton();
		_nextButton.setEnabled(false);
		_nextButton.setText(_nextLabel);
		oComponents[3] = _nextButton;
				
		//define the order label
		_orderLabel = new JLabel();
		_orderLabel.setText(_graphCurrentOrder + 0);
		oComponents[4] = _orderLabel; 
		
		//add the components to the group box...
		setGroupBox(	_pane, 
						"Algorithm Selection", BorderLayout.NORTH,
						oComponents, new FlowLayout());
		
		//Add component handler
		ButtonHandler bh = new ButtonHandler();
		_nextButton.addActionListener (bh);
		
		//Add component handler
		ButtonHandler bh1 = new ButtonHandler();
		_reloadButton.addActionListener (bh1);
		
		ComboHandler ch = new ComboHandler();
		_algoCombo.addActionListener (ch);
	}
	
	//Gets the elementGraph oobject for a given order
	private ElementGraph getElementGraphForOrderN(int order)
	{
		_nDegreeGraph = _xmlAdapter.GetElementGraphForOrderN(_selectedAlgo, _erd, _booleanGraph, _nDegreeGraph, order);
		
		return _nDegreeGraph;
	}

	//Handles the action on the combobox UI component
	private class ComboHandler implements ActionListener
	{
		public void actionPerformed (ActionEvent e)
		{
			_reloadButton.setEnabled(true);
			_nextButton.setEnabled(true);
			JComboBox combo = (JComboBox)e.getSource();
			if (combo.getName() == _algoCb)
			{
				String oldSelectedAlgo = _selectedAlgo;
				_selectedAlgo = combo.getSelectedItem().toString();
				
				//reset the current order to 0, when the user changes the algorithm...
				if (oldSelectedAlgo.contentEquals(_selectedAlgo))
					_currentOrder = 0;
				if (_selectedAlgo.contentEquals(_selectAlgo))
				{
					_reloadButton.setEnabled(false);
					_nextButton.setEnabled(false);
				}
			}
		}
	}

	//Handles the action on the button UI component
	private class ButtonHandler implements ActionListener
	{
		public void actionPerformed (ActionEvent e)
		{
			if (e.getActionCommand() == _nextLabel)
			{
				GenerateGraph(true);
			}
			else if (e.getActionCommand() == _reloadLabel)
			{
				_currentOrder = 1;
				_filePath = _filePathText.getText();
				GenerateGraph(true);
			}
		}
	}
	
	//This method is used for the execution time automated test
	public void AutomatedTestGenerateGraph(String path, String testName, int maxOrder)
	{
		m801.utils.PerformanceLogBuilder.messageBuilderStart(testName,maxOrder,  new Date());

		_filePath = path + testName;
		_selectedAlgo = Globals._ENHANCEDBOWERS;
		
		for (int i=0; i< maxOrder; i++)
			GenerateGraph(false);
		
		m801.utils.PerformanceLogBuilder.messageBuilderEnd(testName,maxOrder, new Date());
		m801.utils.File.Write(m801.utils.PerformanceLogBuilder.get());
	}
	
	//Transforms the graph object into a table with rows and columns 
	private void GenerateGraph(Boolean bDisplayTable)
	{	
		if (_nextButton!=null)
			_nextButton.setEnabled(true);
		
		if (_currentOrder == 1)
		{
			_xmlAdapter = new XmlAdapter(_filePath);
			_erd = _xmlAdapter.createERD(_selectedAlgo);
			
			//Utils.PerformanceLogBuilder.messageBuilderStart("createInitialGraph",_currentOrder,  new Date());
			_booleanGraph = _xmlAdapter.createInitialGraph(_selectedAlgo,_erd);
			//Utils.PerformanceLogBuilder.messageBuilderStart("createInitialGraph",_currentOrder,  new Date());
			
			if (_orderLabel!=null)
				_orderLabel.setText(_graphCurrentOrder + 2);
		}
		else if (_currentOrder == 2)
			_currentOrder++;
		
		//remove the relationships
		String[] pathsToRemove = getPathsToRemoveFromUI();
		_nDegreeGraph = _xmlAdapter.RemovePartition(_selectedAlgo,  (ElementGraph)_nDegreeGraph, pathsToRemove);

		//Utils.PerformanceLogBuilder.messageBuilderStart("getElementGraphForOrderN",_currentOrder,  new Date());
		//get the next graph based on the required order...
		_nDegreeGraph = getElementGraphForOrderN(_currentOrder);
		//Utils.PerformanceLogBuilder.messageBuilderEnd("getElementGraphForOrderN",_currentOrder,  new Date());
		
		//show the potential redundant relationships results in the grid
		if (bDisplayTable)
			displayTable();
					
		if (_currentOrder >= 2)
			if (_orderLabel!=null)
				_orderLabel.setText(_graphCurrentOrder + _currentOrder);

		_currentOrder++;
		
		//defaults in case there is no more path to go through...
		//if (_currentOrder == _booleanGraph.getVerticeSize()+1)
		//{
		//	_nextButton.setEnabled(false);
		//	_orderLabel.setText(_graphEndPath);
		//}
	}
	
	//Get the path list to remove from the graph object 
	private String[] getPathsToRemoveFromUI()
	{
		String[] pathsToRemove =null;
		
		int k = 0;
		
		if (_rn != null)
		{
			pathsToRemove = new String[_rn.getRowCount()];

			Object[][] oPathsToRemove = _rn.getValues();
			for (int i = 0; i< _rn.getRowCount(); i++)
			{
				if (oPathsToRemove[i] != null)
				{
					//only when the user select the row to Yes and there is a short path in the 
					//first column, for the given selected row
					if (Boolean.parseBoolean(oPathsToRemove[i][1].toString()) == true &&
						((String)oPathsToRemove[i][0]).contentEquals(Globals.EMPTY))
					{
						pathsToRemove[k] = oPathsToRemove[i][0].toString();
						k++;
					}
				}
				else
					break;
			}
		}

		return pathsToRemove;
	}
		
	//Render the table in the UI
	private void displayTable()
	{
		//get potential superflous relationships...
		_rn = new RelationshipNames();

		List<PotentialRedundantRelationship> prr = _xmlAdapter.getPotentialRedundantRels();
		_rn.setPathRow(prr, _erd);
		
		//Add the table to the pane...
		JTable table = new JTable(_rn);
		//table.setAutoscrolls(true);
		table.setSize(1000, 1000);
		for (int i = 0; i < 10000; i++)
			table.setRowHeight(i, 100);
		table.setVisible(true);
		
		TableColumnModel tcm =  table.getColumnModel();
		
		//table columns renderers...
		TableColumn tc0 = tcm.getColumn(TableValues.POTENTIAL_REDUDANT_PATH);
		tc0.setCellRenderer(new MultiLineCellRenderer());
		TableColumn tc1 = tcm.getColumn(TableValues.REMOVE);
		tc1.setCellRenderer(new RemoveRenderer());
		tc1.setCellEditor(new RemoveEditor());
		TableColumn tc2 = tcm.getColumn(TableValues.EQUVALENT_PATH);
		tc2.setCellRenderer(new MultiLineCellRenderer());
		
		
		JScrollPane jsp = new JScrollPane(table);
		jsp.setName(_masterGrid);
		
		for (int i = 0; i< _pane.getComponents().length; i++)
		{	
			if (_pane.getComponent(i).getName() == _masterGrid)
			{
				_pane.remove(i);
			}
		}
		_pane.add(jsp,BorderLayout.CENTER);
				
		//mve the column second column at the end
		table.moveColumn(1, 2);
	}
	
	//Fill the combox box with a list of strings
	private JComboBox fillCombo(String[] itemNames, String name, int selectedIndex )
	{
		JComboBox list = new JComboBox();
		list.setName(name);
		for (String itemName: itemNames)
			list.addItem(itemName);
		
		list.setSelectedIndex(selectedIndex);
		
		return list;
	}
	
	//Set the components in the UI 
	private void setGroupBox(	Container pane, 
								String titleName, 
								String borderLayout,  
								Object[] oComponents,
								FlowLayout flowLayout)
	{
		JPanel innerPanel = new JPanel();
		JPanel outerPanel = new JPanel();
		BevelBorder bb =  new BevelBorder(BevelBorder.RAISED);
		TitledBorder tb = new TitledBorder(bb, titleName);
		innerPanel.setBorder(tb);
		outerPanel.add(innerPanel);
		innerPanel.setLayout(flowLayout);
		
		for (Object oComponent: oComponents)
			innerPanel.add((Component)oComponent);
		
		pane.add(outerPanel, borderLayout);
	}
	
	private EntityRelationshipDiagram _erd;
	private JComboBox _algoCombo;
	private BooleanGraph _booleanGraph;
	private String _selectedAlgo;
	private XmlAdapter _xmlAdapter;
	private int _currentOrder;
	private ElementGraph _nDegreeGraph;
	private Container _pane;
	private JLabel _orderLabel;
	private JButton _nextButton;
	private JButton _reloadButton;
	private String _filePath;
	private RelationshipNames _rn; 
	private String _masterGrid;
	private JTextField _filePathText;
	
	private final String _noAlgoSelected = "NO AGLORITH SELECTED";
	private final String _selectAlgo = "-- Select the Algorithm --";
	private final String _nextLabel = "NEXT >>";
	private final String _reloadLabel = "RELOAD";
	private final String _graphCurrentOrder = "The current graph order is: ";
	private final String _algoCb = "algoCb";
	
	//this is enforced by the comopiler... I have selected a value, but could be any long
	static final long serialVersionUID = 131421; 

}
