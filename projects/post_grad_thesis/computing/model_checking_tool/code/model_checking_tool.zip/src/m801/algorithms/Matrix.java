package m801.algorithms;

import java.util.ArrayList;
import java.util.List;

//This is the matrix object representartion
public class Matrix 
{
	//The constructor
	public Matrix()
	{
		_elements =  new ArrayList<Element>();
	}
	
	//Get the list of the matrix element
	public List<Element> getElements()
	{
		return _elements;
	}
	
	//Set the list of the matrix elements
	public void setElements(List<Element> elements)
	{
		_elements = elements;
	}
	
	private List<Element> _elements;
}
