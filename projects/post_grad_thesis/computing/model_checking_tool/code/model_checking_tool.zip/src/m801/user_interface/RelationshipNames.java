package m801.user_interface;

import java.util.List;

import m801.algorithms.GraphOperations;
import m801.algorithms.Partition;
import m801.algorithms.PotentialRedundantRelationship;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;
import m801.utils.Globals;

//This class extends the TableValue class
public class RelationshipNames extends TableValues
{
	//It set the relationships names in the table rows
	public void setPathRow(List<PotentialRedundantRelationship> prrs, EntityRelationshipDiagram erd)
	{
		Object[][] values = null;
		Object[][] tempValues = null;
		
		if (prrs.size() == 0)
		{
			values = setDefaultValues();
		}
		else
		{
			PotentialRedundantRelationship prr =null;
			Relationship rel =null;
			Partition part = null;
			List<String> allRemovedPaths = GraphOperations.getAllRemovedPaths();;
			List<String> paths =null;
	
			if (prrs.size() > 0)
			{
				for(int i = 0; i<prrs.size(); i++)
				{
					prr =  prrs.get(i);
					part = prr.getPartition();
					
					if (allRemovedPaths != null && allRemovedPaths.size() > 0)
						paths = m801.utils.UI.getPathName(prr.getRelationship().getName(), prr.getFromEntity(), part, allRemovedPaths, erd);
					else
						paths = m801.utils.UI.getPathName(prr.getRelationship().getName(), prr.getFromEntity(),  part, erd);
					
					if (paths!=null && paths.size() > 0)
					{
						tempValues = new Object[paths.size()][3];
						for (int k = 0; k < paths.size(); k++)
						{
							if ( k < 1)
							{
								rel = prr.getRelationship();
								tempValues[0][0] = 	m801.utils.UI.getPathName(rel.getFrom().getEntityName(), rel.getName(), rel.getTo().getEntityName());
								tempValues[0][1] = new Boolean (Globals.NO);
							}
							else 
							{
								tempValues[k][0] = 	Globals.EMPTY;
								tempValues[k][1] = new Boolean (Globals.NO);
							}
							
							tempValues[k][2] = (String)paths.get(k);
						}
					}
					
					values = reSize(values, tempValues);
				}
			}
		}

		if (values.length == 0)
			values = setDefaultValues();
		
		setValues(values);
	}
	
	//It set the default value for each column for a given row
	private Object[][] setDefaultValues()
	{
		Object[][] values = new Object[1][COLNUMBER];
		values[0][0] = "There is no redundant relationship";
		values[0][1] = new Boolean (Globals.NO);
		values[0][2] = Globals.EMPTY;
		
		return values;
	}
		
	//It resizes the array of values and insert the temp values
	private Object[][] reSize(Object[][] values, Object[][] temp)
	{
		Object[][] newValues = null;
		int lenTemp = 0;
		int lenValues = 0;
		
		if (temp == null)
			lenTemp = 0;
		else
			lenTemp = temp.length;
		
		if (values == null)
			lenValues = 0;
		else
			lenValues = values.length;
		
		//create a newValues object based on the size info find above...
		newValues = new Object[lenTemp+lenValues][COLNUMBER];
		
		//insert the values array into the newValues array
		for (int i=0; i<lenValues; i++)
		{
			for (int j=0; j<COLNUMBER; j++)
				newValues[i][j] = values[i][j];
		}
		
		//insert the values array into the newValues array
		for (int i=0; i<lenTemp; i++)
		{
			for (int j=0; j<COLNUMBER; j++)
				if (newValues[lenValues+i][j] == null)
					newValues[lenValues+i][j] = temp[i][j];
		}
		
		return newValues; 
	}
	
	private static int COLNUMBER = 3;
	
	//this is enforced by the comopiler... I have selected a value, but could be any long
	static final long serialVersionUID = 131418; 
}
