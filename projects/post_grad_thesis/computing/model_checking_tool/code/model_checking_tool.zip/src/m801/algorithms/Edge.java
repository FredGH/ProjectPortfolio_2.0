package m801.algorithms;

public class Edge 
{
	private int _vertice1 =0;
	private int _vertice2 =0;
	
	//This is the constrcutor
	public Edge (int vertice1, int vertice2 )
	{
		_vertice1 = vertice1;
		_vertice2 = vertice2;
	}
	
	//This method gets the vertice1 from an edge
	public int getVertice1()
	{
		return _vertice1;
	}
	
	//This method gets the vertice2 from an edge
	public int getVertice2()
	{
		return _vertice2;
	}

}
