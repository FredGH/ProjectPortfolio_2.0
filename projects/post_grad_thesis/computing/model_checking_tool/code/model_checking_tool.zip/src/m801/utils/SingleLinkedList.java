package m801.utils;

public class SingleLinkedList {
   private ListNode _firstNode;
   private ListNode _lastNode;
   private String _name;  // String like "list" used in printing

   // Constructor: Construct an empty List with s as the name
   public SingleLinkedList( String s )
   {
      _name = s;
      _firstNode = _lastNode = null;
   }

   // Constructor: Construct an empty List with
   // "list" as the name
   public SingleLinkedList() { this( "list" ); }                             

   // Insert an Object at the front of the List
   // If List is empty, firstNode and lastNode will refer to
   // the same object. Otherwise, firstNode refers to new node.
   public void insertAtFront( Object insertItem )
   {
      if ( isEmpty() )
         _firstNode = _lastNode = new ListNode( insertItem );
      else 
         _firstNode = new ListNode( insertItem, _firstNode );
   }

   // Insert an Object at the end of the List
   // If List is empty, firstNode and lastNode will refer to
   // the same Object. Otherwise, lastNode's next instance
   // variable refers to new node.
   public void insertAtBack( Object insertItem )
   {
      if ( isEmpty() )
         _firstNode = _lastNode = new ListNode( insertItem );
      else 
         _lastNode = _lastNode.next = new ListNode( insertItem );
   }

   // Remove the first node from the List.
   public Object removeFromFront()
          throws EmptyListException
   {
      Object removeItem = null;

      if ( isEmpty() )
         throw new EmptyListException( _name );

      removeItem = _firstNode.data;  // retrieve the data

      // reset the firstNode and lastNode references
      if ( _firstNode.equals( _lastNode ) )
         _firstNode = _lastNode = null;
      else
         _firstNode = _firstNode.next;

      return removeItem;  
   }

   // Remove the last node from the List.
   public Object removeFromBack()
          throws EmptyListException
   {
      Object removeItem = null;

      if ( isEmpty() )
         throw new EmptyListException( _name );

      removeItem = _lastNode.data;  // retrieve the data

      // reset the firstNode and lastNode references
      if ( _firstNode.equals( _lastNode ) )
         _firstNode = _lastNode = null;
      else {
         ListNode current = _firstNode;

         while ( current.next != _lastNode )  // not last node
            current = current.next;      // move to next node
   
         _lastNode = current;
         current.next = null;
      }

      return removeItem;
   }

   // Return true if the List is empty
   public boolean isEmpty()
      { return _firstNode == null; }
   
   // Return true if the List is empty
   public Object getFirstNode()
      { return _firstNode; }
   
   //Get the node object for a given index
   public Object getNode(int index)
   {
	   if (_firstNode == null)
		   return null;
	   
	   ListNode currentNode = _firstNode;
	   while (index > 0)
	   {
		   currentNode = currentNode.next ;
		   index--;
	   }
	   
	   return currentNode.data;
   }
   
   //Get the size of list
   public int size()
   {
	   if (_firstNode == null)
		   return 0;
	  
	   int index =0;
	   ListNode currentNode = _firstNode;
	   while (currentNode !=null)
	   {
		   currentNode = currentNode.next ;
		   index++;
	   }
	   
	   return index;
   }
}