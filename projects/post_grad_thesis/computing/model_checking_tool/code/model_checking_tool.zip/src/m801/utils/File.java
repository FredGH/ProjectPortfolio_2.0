package m801.utils;

import java.io.*;
import java.util.ArrayList;

import m801.logger.EntityRelationshipDiagramPlugin;

import org.eclipse.core.runtime.IStatus;

//This class enable to write to a file
public class File 
{
	//Write string array data to a file
	public static void Write(ArrayList<String> lsData)
	{
		FileWriter fw = null;
		try
		{
			fw = new FileWriter("PerformanceLogger.txt");
		}
		catch(IOException ioe)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, ioe.getMessage(), ioe);
		}
		PrintWriter pw = new PrintWriter(fw);
		for (String str:lsData)
			pw.println(str);
		
		pw.close();		
	}
}
