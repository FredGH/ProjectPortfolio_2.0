package m801.business_objects;

//This class represents the attribute object
public class Attribute 
{
	//The constructor
	public Attribute()
	{
		_name = "";
		_type = "";
		_primaryKey = false;
		_foreignKey = true;
	}
	
	//Set the attribute name
	public void setName(String name)
	{
		_name = name;
	}
	
	//Get the attribute name
	public String getName()
	{
		return _name;
	}
	
	//Set the attribute type
	public void setType(String type)
	{
		_type=type;
	}
	
	//Set the primary key object
	public void setPrimaryKey(String primaryKey)
	{
		_primaryKey = Boolean.parseBoolean(primaryKey);
	}
	
	//Set the foreign key object
	public void setForeignKey(String foreignKey)
	{
		_foreignKey = Boolean.parseBoolean(foreignKey);
	}
	
	//Attribute object to String
	public String toString()
	{
		return "attribute name=" +_name + " type=" + _type + " primaryKey=" + _primaryKey + " foreignKey=" + _foreignKey;
	}
	
	//Indicates whether the attribbute is a primar or not.
	public boolean isPrimaryKey()
	{
		return _primaryKey;
	}
	
	private String _name;
	private String _type;
	private boolean _primaryKey;
	private boolean _foreignKey;
}
