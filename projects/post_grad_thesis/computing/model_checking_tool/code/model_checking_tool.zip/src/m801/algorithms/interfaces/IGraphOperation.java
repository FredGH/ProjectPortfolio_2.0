package m801.algorithms.interfaces;

import java.util.List;

import m801.algorithms.BooleanGraph;
import m801.algorithms.ElementGraph;
import m801.algorithms.PotentialRedundantRelationship;
import m801.business_objects.EntityRelationshipDiagram;
import m801.utils.SingleLinkedList;


//Interface for the Graph Operation
public interface IGraphOperation 
{
	//Create a graph of order n
	public IGraph createGraphOrderN(int order, EntityRelationshipDiagram erd) throws Exception;
	
	public List<PotentialRedundantRelationship> getPotentialRedundantRelationships(	EntityRelationshipDiagram erd,
																					BooleanGraph booleanGraph, 
																					ElementGraph elementGraph);
	
	// This method removes partition(s) given a set of relationships to delete.
	public ElementGraph removePartition(ElementGraph elementGraph, String[] pathsToRemove);
	
	// This method removes partition(s) given a set of relationships to delete.
	public ElementGraph removeUnwantedPartition(	EntityRelationshipDiagram erd,
													BooleanGraph booleanGraph, 
													ElementGraph elementGraph);
	
	//Clone the enitity linked list of the graph
	public List<SingleLinkedList> cloneEntityLinkedLists(List<SingleLinkedList> entitySingleLinkedList);
}
