package m801.business_objects;

//This class represents the constraint attribute object
public class ConstraintEndAttribute 
{
	//The constructor
	public ConstraintEndAttribute()
	{
		_name = "";
	}
	
	//Set the attribute name
	public void setName(String name)
	{
		_name = name;
	}
	
	//Get the attribute name
	public String getName()
	{
		return _name;
	}
	
	//Object to String representation
	public String toString()
	{
		return "constraintEnd attribute name=" +_name ;
	}
	
	private String _name;
}
