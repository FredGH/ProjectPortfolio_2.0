package m801.user_interface;

import java.awt.Component;
import java.util.EventObject;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;

import m801.utils.Globals;


//This class interprets the value in the JComboBox
public class RemoveEditor extends JComboBox implements TableCellEditor
{
	protected EventListenerList listenerList = new EventListenerList();
	protected ChangeEvent changeEvent = new ChangeEvent(this);
	
	public RemoveEditor()
	{
	
		super();
		addItem(Globals.YES);
		addItem(Globals.NO);
		
		addActionListener
		(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent event)
				{
					fireEditingStopped();
				}
			}
		);
	}
	
	//Overriedes the addCellEditorListener 
	public void addCellEditorListener(CellEditorListener listener)
	{
		listenerList.add(CellEditorListener.class, listener);
	}
	
	//Overriedes the removeCellEditorListener
	public void removeCellEditorListener(CellEditorListener listener)
	{
		listenerList.remove(CellEditorListener.class, listener);
	}
	
	//Overriedes the fireEditingStopped
	protected void fireEditingStopped()
	{
		CellEditorListener listener;
		Object[] listeners = listenerList.getListenerList();
		for (int i=0; i<listeners.length; i++)
		{
			if (listeners[i] == CellEditorListener.class)
			{
				listener = (CellEditorListener) listeners[i+1];
				listener.editingStopped(changeEvent);
			}
		}
	}
	
	//Overriedes the fireEditingCanceled
	protected void fireEditingCanceled()
	{
		CellEditorListener listener;
		Object[] listeners = listenerList.getListenerList();
		for (int i=0; i<listeners.length; i++)
		{
			if (listeners[i] == CellEditorListener.class)
			{
				listener = (CellEditorListener) listeners[i+1];
				listener.editingCanceled(changeEvent);
			}
		}
	}
	
	//Overriedes the cancelCellEditing
	public void cancelCellEditing()
	{
		fireEditingCanceled();
	}
	
	//Overriedes the stopCellEditing
	public boolean stopCellEditing()
	{
		fireEditingStopped();
		return true;
	}
	
	//Overriedes the isCellEditable
	public boolean isCellEditable(EventObject event)
	{
		return true;
	}
	
	//Overriedes the shouldSelectCell
	public boolean shouldSelectCell(EventObject event)
	{
		return true;
	}
	
	//Overriedes the getCellEditorValue
	public Object getCellEditorValue()
	{
		return new Boolean(getSelectedIndex() == 0? true:false);
	}
	
	//Overriedes the getTableCellEditorComponent
	public Component getTableCellEditorComponent(	JTable table, 
													Object value, 
													boolean isSelected,
													int row, 
													int column)
	{
		boolean isYes = ((Boolean)value).booleanValue();
		setSelectedIndex(isYes ? 0 : 1);
		
		return this;
	}
	
	//this is enforced by the comopiler... I have selected a value, but could be any long
	static final long serialVersionUID = 131419; 
}