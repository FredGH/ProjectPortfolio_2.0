package m801.business_objects;

//This class represents the relationship object
public class Relationship 
{
	//The constructor
	public Relationship()
	{
		_RelationshipEnd1 = new RelationshipEnd();
		_RelationshipEnd2 = new RelationshipEnd();
		_name = "";
	}
	
	//Get the relationship name
	public String getName()
	{
		return _name;
	}
	
	//Set the relationship name
	public void setName(String name)
	{
		_name = name;
	}
	
	//Get the fromEntity
	public RelationshipEnd getFrom()
	{
		return _RelationshipEnd1;
	}
	
	//Set the fromEntity
	public void setFrom(RelationshipEnd relationshipEnd)
	{
		_RelationshipEnd1 = relationshipEnd;
	}
	
	//Get the relationship end of the toEntity
	public RelationshipEnd getTo()
	{
		return _RelationshipEnd2;
	}
	
	//Set the relationship end of the toEntity
	public void setTo(RelationshipEnd relationshipEnd)
	{
		_RelationshipEnd2 = relationshipEnd;
	}
	
	//Object representartion to String
	public String ToString()
	{
		return "relationship " +
			   "entity1="+_RelationshipEnd1.getEntityName() + " " +
			   "direction1="+_RelationshipEnd1.getDirection() + " " +
			   "optionality1="+ _RelationshipEnd1.getOptionality().toString() +
			   "("+_RelationshipEnd1.getOptionalityToScalar()+")" + " " +
			   "degree1="+_RelationshipEnd1.getDegree().toString() +
			   "("+_RelationshipEnd1.getDegreeToScalar()+")" + " " +
			   "entity2="+_RelationshipEnd2.getEntityName().toString() + " " +
			   "direction2="+_RelationshipEnd2.getDirection() + " " +
			   "optionality2="+ _RelationshipEnd2.getOptionality().toString() +
			   "("+_RelationshipEnd2.getOptionalityToScalar()+")" +
			   "degree2="+_RelationshipEnd2.getDegree().toString() + " " +
			   "("+_RelationshipEnd2.getDegreeToScalar()+")";
	}

	private RelationshipEnd _RelationshipEnd1;
	private RelationshipEnd _RelationshipEnd2;	
	private String _name;
}
