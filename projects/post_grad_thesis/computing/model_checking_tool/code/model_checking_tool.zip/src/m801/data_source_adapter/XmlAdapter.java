package m801.data_source_adapter;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import m801.algorithms.BooleanGraph;
import m801.algorithms.ElementGraph;
import m801.algorithms.EnhancedBowers;
import m801.algorithms.GraphOperations;
import m801.algorithms.PotentialRedundantRelationship;
import m801.algorithms.RosenthalReiner1994;
import m801.business_objects.Attribute;
import m801.business_objects.Constraint;
import m801.business_objects.ConstraintEnd;
import m801.business_objects.ConstraintEndAttribute;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;
import m801.business_objects.RelationshipEnd;
import m801.data_source_adapater.interfaces.IDataSourceAdapter;
import m801.data_source_adapater.interfaces.IGraphCreation;
import m801.logger.EntityRelationshipDiagramPlugin;
import m801.utils.EntityRelationshipBuilder;
import m801.utils.Globals;

import org.eclipse.core.runtime.IStatus;
import org.w3c.dom.*;
import org.xml.sax.SAXException;

//This class adapts the XML ERD representation into the in-memory boolean matrix representation 
public class  XmlAdapter implements IDataSourceAdapter, IGraphCreation 
{	
	//The constructor
	public  XmlAdapter(String filePath)
	{
		_filePath = filePath;
	}
	
	//Get the graph representation of the ERD for a given algoType
	public EntityRelationshipDiagram GetGraph(String algoType)
	{
		return GetGraph(algoType, -1);
	}
	
	//Create the in memory ERD
	public EntityRelationshipDiagram createERD(String algoType)
	{
		EntityRelationshipDiagram erd = (EntityRelationshipDiagram) GetDataSource();
		return erd;
	}
	
	//Create the initial boolean graph given an algoType and an ERD
	public BooleanGraph createInitialGraph(String algoType, EntityRelationshipDiagram erd)
	{
		BooleanGraph booleanGraph = null;
		try
		{
			GraphOperations go = GetGraphOperation(algoType);
			booleanGraph = (BooleanGraph)go.createInitialGraph (erd);
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		
		return booleanGraph;
	}
	
	//Get an element graph for a given order, algo and erd
	public ElementGraph GetElementGraphForOrderN(	String algoType, 
													EntityRelationshipDiagram erd,  
													BooleanGraph booleanGraph,
													ElementGraph nDegreeGraph,
													int order)
	{
				
		//get the nDegreeGraph....
		GraphOperations go = GetGraphOperation(algoType);
		if (order < 2)
			nDegreeGraph = go.getNDegreeGraph(booleanGraph, booleanGraph, erd, order);
		else
			nDegreeGraph = go.getNDegreeGraph(booleanGraph, nDegreeGraph.clone(), erd, order);
		
		//remove unwanted relationships (i.e. relationships that display recursion when there is none defined
		//in the model or multiple relationships when the defined number of multiple relationships is less than
		//the number produced by the matrix multiplication
		//go.removeUnwantedPartition(erd, booleanGraph, nDegreeGraph);
		
		//finally deduce the redundant relationships
		_potentialRedundantRels = go.getPotentialRedundantRelationships(erd, booleanGraph, nDegreeGraph);
				
		return nDegreeGraph;
		
	}

	//Get the list of potential redundant relationships
	public List<PotentialRedundantRelationship> getPotentialRedundantRels()
	{
		return _potentialRedundantRels;
	}
	
	//Remove a partition given the parameter list
	public ElementGraph RemovePartition (String algoType, ElementGraph elementGraph, String[] pathsToRemove)
	{
		GraphOperations go = GetGraphOperation(algoType);
		ElementGraph newElementGraph = go.removePartition(elementGraph, pathsToRemove);
		return newElementGraph;
	}
	
	//Load the data into the business object
	public EntityRelationshipDiagram GetGraph(String algoType, int order)
	{
		EntityRelationshipDiagram erd =null;
		GraphOperations go = null;
		
		try
		{
			//create the ERD
			erd = (EntityRelationshipDiagram) GetDataSource();
			
			//as default get the erd max size
			if (order == -1)
				order = erd.getEntities().size();
	
			go = GetGraphOperation(algoType);
			
			go.createGraphOrderN(order, erd);
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		return erd;		
	}
		
	//Get the data source object
	public  Object GetDataSource()
	{
		Document doc = null;
		
		try {
	
			if (_filePath == "")
				throw new Exception ("The file path is missing...");
			
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			factory.setNamespaceAware(true);
			DocumentBuilder builder = factory.newDocumentBuilder();
			doc = builder.parse(_filePath);
			
			EntityRelationshipDiagram erd = adaptERD(doc);
			
			return erd;
			
		} 
		catch (ParserConfigurationException e) 
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		} 
		catch (SAXException e) 
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		catch (IOException e) 
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		
		return doc;
	}
	
	//Adapt the the XML document into a EntityRelationshipDiagram object
	private EntityRelationshipDiagram adaptERD(Document doc)
	{
		EntityRelationshipBuilder erbuilder = new EntityRelationshipBuilder();

		//get the entity list (including their attrbutes)
		List<Entity> entities = adaptEntity(doc, erbuilder);
		
		//get the list of relationships
		List<Relationship> relationships = adaptRelationship(doc, erbuilder);
		
		//get the list of constraints
		List<Constraint> constraints = adaptConstraint(doc, erbuilder);
		
		//get the ERD data
		NodeList diagramNodeList = (NodeList) doc.getElementsByTagName("diagram");
		NamedNodeMap mnmDiagram =  diagramNodeList.item(0).getAttributes();
		String diagramName =  ((Attr)mnmDiagram.item(0)).getValue().toString();
		String diagramType =  ((Attr)mnmDiagram.item(1)).getValue().toString();
		
		//create the ERD
		EntityRelationshipDiagram erd = erbuilder.CreateEntityRelationshipDiagram(diagramName, diagramType, entities, relationships, constraints);
		
		return erd;
	
	}
	
	//Adapt the XML doc into an Entity List
	private List<Entity> adaptEntity(Document doc, EntityRelationshipBuilder erbuilder)
	{
		Node attributeNode =null;
		NodeList entityNodeList =null;
		Attribute attribute =null;
		m801.business_objects.Entity entity = null;
		NamedNodeMap mnmAttributes =null;
		NamedNodeMap mnmEntity =null; 
		List<Attribute> attributeList = null;
		List<Entity>  entities = new ArrayList<Entity>();
		String entityName ="";
		
		NodeList entityList = (NodeList) doc.getElementsByTagName("entity");
		if(entityList!=null)
		{
			for (int i=0; i< entityList.getLength(); i++)
			{	
				//get entity data
				mnmEntity = entityList.item(i).getAttributes();
				if (mnmEntity!=null && mnmEntity.getLength() >0)
				{
					entityName = ((Attr)mnmEntity.item(0)).getValue().toString();
				}
	
				//get attributes data
				attributeList = new ArrayList<Attribute>();
				entityNodeList = entityList.item(i).getChildNodes();
				if (entityNodeList!=null)
				{
					for(int j=0; j< entityNodeList.getLength(); j++)
					{
						attributeNode = entityNodeList.item(j);
						if (attributeNode.getNodeType() == org.w3c.dom.Element.ELEMENT_NODE)
						{		
							mnmAttributes = attributeNode.getAttributes();
							
							if (mnmAttributes!=null && mnmAttributes.getLength() >0)
							{
								attribute = erbuilder.CreateAttribute(	((Attr)mnmAttributes.getNamedItem("name")).getValue().toString(),
																		((Attr)mnmAttributes.getNamedItem("type")).getValue().toString(),
																		"TODO", "TODO");
							}
							
							//add attribute to attributeList
							attributeList.add(attribute);					
						}
					}		
				}
				
				//create entity
				entity = erbuilder.CreateEntity(entityName, attributeList);
				entities.add(entity);
			}
		}
		
		return entities;
	}
	
	//Adapt the Relatinships into a relationship list
	private List<Relationship> adaptRelationship(Document doc, EntityRelationshipBuilder erbuilder)
	{
		Node relationshipEndNode =null;
		Node tempRelationshipNode =null;
		NodeList relationshipEndNodeList =null;
		NamedNodeMap mnmrelationshipEnd =null;
		NodeList intialRelationshipList =null;
		String entityName ="";
		String optionality ="";
		String degree ="";
		String direction ="";
		Relationship relationship =null;
		RelationshipEnd relationshipEnd = null;
		List<RelationshipEnd> relationshipEndList = new ArrayList<RelationshipEnd>();
		List<Relationship> relationshipList = new ArrayList<Relationship>();
		ArrayList<Object> tempRelationshipList = new ArrayList<Object>();
		String name;
		int count =0;
		
		intialRelationshipList = (NodeList) doc.getElementsByTagName("relationship");
		for (int j=0; j< intialRelationshipList.getLength(); j++)
		{
			//get attributes data
			tempRelationshipNode = intialRelationshipList.item(j);
			if (tempRelationshipNode!=null)
			{
				tempRelationshipList.add(((Attr)tempRelationshipNode.getAttributes().getNamedItem("name")).getValue().toString());
			}
		}
		
		relationshipEndNodeList = (NodeList) doc.getElementsByTagName("relationshipEnd");
		if(relationshipEndNodeList!=null)
		{
			for (int i=0; i< relationshipEndNodeList.getLength(); i++)
			{	
				//get attributes data
				relationshipEndNode = relationshipEndNodeList.item(i);
				if (relationshipEndNode!=null)
				{
					mnmrelationshipEnd = relationshipEndNode.getAttributes();
					
					if (mnmrelationshipEnd!=null && mnmrelationshipEnd.getLength()>0)
					{
						entityName =  ((Attr)mnmrelationshipEnd.getNamedItem("entity")).getValue().toString();
						direction =   ((Attr)mnmrelationshipEnd.getNamedItem("direction")).getValue().toString();
						optionality = ((Attr)mnmrelationshipEnd.getNamedItem("optionality")).getValue().toString();
						degree 		= ((Attr)mnmrelationshipEnd.getNamedItem("degree")).getValue().toString();
						
						relationshipEnd = erbuilder.CreateRelationshipEnd(	entityName,
																			direction,
																			optionality,
																			degree);	
						
						//add relationshipEnd to relationshipEndList
						relationshipEndList.add(relationshipEnd);
					}
					
					
					if (i%2 != 0)
					{
						name = tempRelationshipList.get(count++).toString();
						//create entity
						relationship = erbuilder.CreateRelationship(    name, 
																		relationshipEndList.get(0), 
																		relationshipEndList.get(1));
						relationshipList.add(relationship);
						relationshipEndList = new ArrayList<RelationshipEnd>();
					}
				}
			}
		}
		
		return relationshipList;
	}

	//Adapt the XML document into a contrainst list
	private List<Constraint> adaptConstraint(Document doc, EntityRelationshipBuilder erbuilder)
	{
		
		Node constraintEndNode =null;
		NodeList constraintEndNodeList =null;
		NamedNodeMap mnmconstraintEnd =null;
		String entityName ="";
		String direction ="";
		String name ="";
		Constraint constraint =null;
		ConstraintEnd constraintEnd = null;
		ConstraintEndAttribute constraintEndAttribute =null;
		NodeList attributeNodeList =null;
		Node attributeNode =null;
		NodeList attributes =null;
		List<ConstraintEnd> constraintEndList =null;
		List<Constraint> constraintList = new ArrayList<Constraint>();
		List<ConstraintEndAttribute> ConstraintEndAttributeList = null;
		
		constraintEndNodeList = (NodeList) doc.getElementsByTagName("constraintEnd");
		if(constraintEndNodeList!=null)
		{
			constraintEndList = new ArrayList<ConstraintEnd>();
			for (int i=0; i< constraintEndNodeList.getLength(); i++)
			{	
				constraintEndNode = constraintEndNodeList.item(i);
				if (constraintEndNode!=null)
				{
					mnmconstraintEnd = constraintEndNode.getAttributes();
					
					if (mnmconstraintEnd!=null && mnmconstraintEnd.getLength()>0)
					{
						entityName =  ((Attr)mnmconstraintEnd.getNamedItem("entity")).getValue().toString();
						direction =   ((Attr)mnmconstraintEnd.getNamedItem("direction")).getValue().toString();
						
						attributeNodeList = constraintEndNode.getChildNodes();
						
						if (attributeNodeList!=null)
						{
							ConstraintEndAttributeList = new  ArrayList<ConstraintEndAttribute>();
							for(int j=0; j<attributeNodeList.getLength(); j++)
							{
								attributeNode = attributeNodeList.item(j);
								attributes = attributeNode.getChildNodes();
								if (attributes!=null)
								{
									
									for(int k=0; k<attributes.getLength(); k++)
									{
										Node attribute = attributes.item(k);
										if (attribute.getNodeType() == org.w3c.dom.Element.ELEMENT_NODE)
										{
											NamedNodeMap mnpAttribute= attribute.getAttributes();
											name =  ((Attr)mnpAttribute.getNamedItem("name")).getValue().toString();
											constraintEndAttribute = erbuilder.CreateConstraintEndAttribute(name);
											ConstraintEndAttributeList.add(constraintEndAttribute);
										}
									}
								}
							}
							
							//create constraint end
							constraintEnd = erbuilder.CreateConstraintEnd(	entityName,
																			direction,
																			ConstraintEndAttributeList);
							constraintEndList.add(constraintEnd);
						}
						
						if (i%2 != 0)
						{
							//create constraint
							constraint = erbuilder.CreateConstraint(constraintEndList.get(0), constraintEndList.get(1));
							constraintList.add(constraint);
							constraintEndList = new ArrayList<ConstraintEnd>();
						}
					}
				}
			}
		}
		
		return constraintList;
	}
	
	//Select the algo implementation for a given alo Type
	private GraphOperations GetGraphOperation(String algoType) 
	{
		GraphOperations go = null;
		
		if (algoType == Globals._ENHANCEDBOWERS)
			go = new EnhancedBowers();
		else if (algoType == Globals._ROSENTHALREINER)
			go = new RosenthalReiner1994();
		return go;
	}
	
	private String _filePath;
	List<PotentialRedundantRelationship>  _potentialRedundantRels;
}
