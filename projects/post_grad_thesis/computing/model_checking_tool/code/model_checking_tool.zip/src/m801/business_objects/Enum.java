package m801.business_objects;

// The business object enums
public class Enum
{
	//Defines the type of degrees
	public enum Optionality
	{
		OPTIONAL,
		MANDATORY
	}
	
	//Defines the type of degress
	public enum Degree
	{
		MANY,
		ONE
	}
	//Defines the type of constraint
	public enum ConstraintType
	{
		INCLUSION
	}
}


