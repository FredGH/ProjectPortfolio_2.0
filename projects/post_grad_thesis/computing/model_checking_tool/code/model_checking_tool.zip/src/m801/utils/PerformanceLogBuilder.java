package m801.utils;

import java.util.ArrayList;
import java.util.Date;

//This class build the log information
public class PerformanceLogBuilder 
{
	//Get the data
	public static ArrayList<String> get()
	{
		return _data;
	}
	
	//Clear the data
	public static void clear()
	{
		if (_data != null)
			_data.clear();
	}
		
	//This method build the start message
	public static void messageBuilderStart(String methodName, int order, Date date)
	{
		messageBuilder("Start: \t" + methodName + "\t - Order: \t" + order, date);
	}
	
	//This method build the end message
	public static void messageBuilderEnd(String methodName, int order,  Date date)
	{
		messageBuilder("End: \t" + methodName + "\t - Order: \t" + order, date);
		
	}
	
	//This method build the message and add it to the list
	public static void messageBuilder(String data, Date date)
	{
		long msec = date.getTime();
		
		add (data + "\t - DateTime: \t" + date + "\t - msec: \t" + msec);
	}
	
	//Add to log
	private static void add(String data)
	{
		if (_data == null)
			_data = new ArrayList<String>();
		
		_data.add(data);
	}

	private static  ArrayList<String> _data;
}