package m801.algorithms;

import m801.algorithms.interfaces.IGraph;
import m801.business_objects.Constraint;
import m801.business_objects.Relationship;
import m801.logger.EntityRelationshipDiagramPlugin;

import org.eclipse.core.runtime.IStatus;

public class BooleanGraph implements IGraph
{
	private int _vertices =0;
	private int _edges =0;
	private EntityLinkageInformation _adj[][] =null;
	
	//This is the contructor
	public BooleanGraph(int vertices)
	{
		_vertices  = vertices;
		_edges = 0;
		_adj = new EntityLinkageInformation[vertices][vertices];
	}
	
	//This method gets the number of vertices in a graph
	public int getVerticeSize()
	{
		return _vertices;
	}
	
	//This method gets the number of edges in a graph
	public int getEdgeSize()
	{
		return _edges;
	}
	
	//This method gets the number of graph size
	public int size()
	{
		return getVerticeSize() * getEdgeSize();
	}
	
	//This method inserts an edge in a graph 
	public void insert(Edge e, /*Object oValue*/ EntityLinkageInformation eli)
	{
		try
		{
			EntityLinkageInformation currentEli12 = null;
			EntityLinkageInformation currentEli21 = null;
			
			int vertice1 = e.getVertice1();
			int vertice2 = e.getVertice2();
			
			//this represent the intial entity linkage information values in the matrix for 2 given vertices
			if (_adj[vertice1][vertice2] !=null)
				currentEli12 = ((EntityLinkageInformation)_adj[vertice1][vertice2]).Clone();
			else
				currentEli12 = new EntityLinkageInformation();
			
			if (_adj[vertice2][vertice1] !=null)
				currentEli21 = ((EntityLinkageInformation)_adj[vertice2][vertice1]).Clone();
			else
				currentEli21 = new EntityLinkageInformation();
				
			for (Relationship relationship: eli.getRelationships())
			{
				currentEli12.addRelationship(relationship);
				currentEli21.addRelationship(relationship);

			}
			
			for (Constraint constraint: eli.getConstraints())
			{
				currentEli12.addConstrainst(constraint);
				currentEli21.addConstrainst(constraint);
			}
						
			//increment the matrix value with the oValue
			_adj[vertice1][vertice2] = currentEli12;
			_adj[vertice2][vertice1] = currentEli21;
		}
		catch (Exception exception)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, exception.getMessage(), exception);
		}
	}
	
	//This method gets graph element information from the vertice1 and vertice2
	public EntityLinkageInformation getElement(int vertice1, int vertice2)
	{
		return (EntityLinkageInformation)_adj[vertice1][vertice2];
	}
	
}