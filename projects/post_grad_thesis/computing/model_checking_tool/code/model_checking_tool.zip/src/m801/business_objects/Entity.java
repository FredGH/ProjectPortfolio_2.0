package m801.business_objects;

import java.util.ArrayList;
import java.util.List;

//This class represents the entity object
public class Entity
{
	//The constructor
	public Entity()
	{
		_name = "";
		_attributes = new ArrayList<Attribute>();
	}
	
	//Deep copy of the entity
	public Entity Clone()
	{
		Entity entity = new Entity();
		entity.setName(getName());
		for(Attribute attribute: getAttributes())
		{
			entity.addAttribute(attribute);
		}
		
		return entity;
	}
	
	//Add an attribute
	public void addAttribute(Attribute attribute)
	{
		if (!_attributes.contains(attribute))
			_attributes.add(attribute);
	}
	
	//Get the list of attributes
	public List<Attribute> getAttributes()
	{
		return _attributes;
	}
	
	//Get the list of attributes that are the primary keys
	public List<Attribute> getAttributePK()
	{
		List<Attribute> attributes =  getAttributes();
		List<Attribute> pkAttributes = new ArrayList<Attribute>();
		
		for (Attribute attribute: attributes)
		{
			if (attribute.isPrimaryKey())
				pkAttributes.add(attribute);
		}
		
		return null;
	}
	
	//This method checks whether a given list of attributes exists in the entity attributes list.
	public boolean hasAttribute1(List<ConstraintEndAttribute> constraintEndAttributes)
	{
		List<Attribute> attributes = new ArrayList<Attribute>();
		Attribute attribute = new Attribute();
		for (ConstraintEndAttribute constraintEndAttribute: constraintEndAttributes)
		{
			attribute = new Attribute();
			attribute.setName(constraintEndAttribute.getName());
			attributes.add(attribute);
		}
		
		return hasAttribute(attributes);

	}
	
	//This method checks whether a given list of attributes exists in the entity attributes list.
	public boolean hasAttribute(List<Attribute> attributes)
	{
		List<Attribute> currentattributes =  getAttributes();
		boolean bFound = false;
		
		for (Attribute attribute: attributes)
		{
			for (Attribute currentAttribute: currentattributes)
			{
				if (currentAttribute.getName().contentEquals(attribute.getName()))
				{
					bFound = true;
					break;
				}
				else
					bFound = false;
			}
			
			if (bFound == false)
				break;
		}
		
		return bFound;
	}
	
	//Set the entity name
	public void setName(String name)
	{
		_name = name;
	}
	
	//Get the eneity name
	public String getName()
	{
		return _name;
	}
	
	//Object to String
	public String toString()
	{
		String message = "entity name = " +_name;
		for (Attribute attribute: _attributes)
		{
			message += "" + attribute.toString() +"";
		}
		
		return message;
	}
	
	private String _name;
	private List<Attribute> _attributes;
 
}