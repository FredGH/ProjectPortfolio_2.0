package m801.algorithms;

import java.util.List;

import m801.business_objects.Attribute;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;

//This class extends the ShortCut class
public class VerticalShortcut extends Shortcut
{
	//Delegates into the parent class
	public VerticalShortcut(	EntityRelationshipDiagram erd,
								List<Relationship> relationships,
								Entity fromEntity,
								List<Attribute> fromEntityAtttibutesPK,
								List<Attribute> fromEntityAtttibutes,
								Entity midEntity,
								List<Attribute> midEntityAtttibutesPK,
								List<Attribute> midEntityAtttibutes,
								Entity toEntity,	
								List<Attribute> toEntityAtttibutesPK,
								List<Attribute> toEntityAtttibutes)
	{
		super(	erd,
				relationships,
				fromEntity, 
				fromEntityAtttibutesPK,
				fromEntityAtttibutes,
				midEntity,
				midEntityAtttibutesPK,
				midEntityAtttibutes,
				toEntity, 
				toEntityAtttibutesPK, 
				toEntityAtttibutes
				);
	}
	

	//This method check whhether the PK attributes are shared accross all entities in the 3 entity cycle
	//This method is not implemented, it returns a default value
	protected boolean isAttributeSharedInAllEntities()
	{
		//DO THE IMPLEMENTATION
		return false;
	}
	
	//This method checls whether there is an inclusion contraint
	//This method is not implemented, it returns a default value
	protected boolean hasInclusionConstraint()
	{
		//DO THE IMPLEMENTATION
		return false;
	}
}
