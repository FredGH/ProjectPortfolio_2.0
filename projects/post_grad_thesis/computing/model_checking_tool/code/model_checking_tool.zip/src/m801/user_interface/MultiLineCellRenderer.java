package m801.user_interface;

import java.awt.*;
import javax.swing.*;
import javax.swing.table.TableCellRenderer;

import m801.utils.Globals;

import java.util.StringTokenizer;

//This class handles the Table cell renderer for a JTextArea
public class MultiLineCellRenderer  extends JTextArea implements TableCellRenderer
{
	
	//This is the overriden getTableCellRendererComponent mehod.
	//It is used to display the name of a series of equivalent path in a JTextArea
	public Component getTableCellRendererComponent(	JTable table, 
													Object value, 
													boolean isSelected, 
													boolean hasFocus, 
													int row, 
													int column)
	{
		JLabel label;
		removeAll();
		StringTokenizer strtok = new StringTokenizer((String)(value), "\r\n");
		setLayout (new GridLayout(strtok.countTokens(), 1));
		while(strtok.hasMoreElements())
		{
			label = new JLabel((String) strtok.nextElement(), JLabel.CENTER );
			label.setFont(Globals.DEFAULTFONT);
			add(label);
			
		}
		
		return this;
	}
	
	//this is enforced by the comopiler... I have selected a value, but could be any long
	static final long serialVersionUID = 131417; 
}
