package m801.algorithms;

//This ithe signature ibject
public class Signature 
{
	//Set the right cardinality of the signature
	public void setRightCardinality(boolean rightCardinality){_rightCardinality = rightCardinality;}
	//Get the right cardinality of the signature
	public boolean getRightCardinality(){ return _rightCardinality;}
	
	//Set the left cardinality of the signature
	public void setLeftCardinality(boolean leftCardinality){_leftCardinality = leftCardinality;}
	//Get the left cardinality of the signature
	public boolean getLeftCardinality(){ return _leftCardinality;}
	
	//Set the left optionality of the signature
	public void setLeftOptionality(boolean leftOptionality){_leftOptionality = leftOptionality;}
	//Get the left optionality of the signature
	public boolean getLeftOptionality(){ return _leftOptionality;}
	
	//Set the right optionality of the signature
	public void setRightOptionality(boolean rightOptionality){_rightOptionality = rightOptionality;}
	//Get the right optionality of the signature
	public boolean getRightOptionality(){ return _rightOptionality;}
	
	private boolean _rightCardinality;
	private boolean _rightOptionality;
	private boolean _leftCardinality;
	private boolean _leftOptionality;
}
