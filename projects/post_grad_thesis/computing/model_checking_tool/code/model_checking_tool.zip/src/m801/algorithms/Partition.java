package m801.algorithms;

import m801.utils.SingleLinkedList;
import m801.utils.UI;

//This is a wrapper object that represents a path between two entities.
//It contains the entity list that constitute the path between a 'from' (i.e. source) and 'to' (i.e. destionation) entity.
//It also contains the composite path signature between these two entities
public class Partition 
{
	//The constructor
	public Partition()
	{
		_signature = new Signature();
		_entitySingleLinkedList = new SingleLinkedList();
	}
		
	//Get the entity list
	public SingleLinkedList getEntityList()
	{
		return 	_entitySingleLinkedList;
	}
	
	//Do a deep copy of the entity linked list
	public SingleLinkedList getEntityListClone()
	{
		SingleLinkedList entitySingleLinkedList = new SingleLinkedList();
		for (int i=0; i<_entitySingleLinkedList.size(); i++)
		{
			entitySingleLinkedList.insertAtBack(_entitySingleLinkedList.getNode(i));
		}
		
		return entitySingleLinkedList;
	}

	//Set the enity linked list
	public void setEntityList(SingleLinkedList entitySingleLinkedList)
	{
		_entitySingleLinkedList = entitySingleLinkedList;
	}
	
	//Get the signature
	public Signature getSignature()
	{
		return _signature;
	}
	
	//Set the signature
	public void setSignature(Signature signature)
	{
		_signature = signature;
	}
	
	//Create a string representation of the Parition object
	public String toString()
	{
		String partName = "";
		
		for (int i= 0; i< _entitySingleLinkedList.size(); i++)
		{
			String from = ((EntityLinkageInformation)_entitySingleLinkedList.getNode(i)).getRelationships().get(0).getFrom().getEntityName();
			String to = ((EntityLinkageInformation)_entitySingleLinkedList.getNode(i)).getRelationships().get(0).getTo().getEntityName();
			String rel = ((EntityLinkageInformation)_entitySingleLinkedList.getNode(i)).getRelationships().get(0).getName();
			
			partName += UI.getPathName(from, rel, to) + "\n" + "AND" + "\n";	
		}
		
		return partName; 
	}
		
	private Signature _signature;
	private SingleLinkedList _entitySingleLinkedList;
}
