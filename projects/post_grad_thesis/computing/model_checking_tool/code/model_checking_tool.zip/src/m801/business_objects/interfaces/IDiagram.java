package m801.business_objects.interfaces;

public class IDiagram 
{

}
