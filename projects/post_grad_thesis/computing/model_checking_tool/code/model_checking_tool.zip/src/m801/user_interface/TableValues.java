package m801.user_interface;

import javax.swing.table.AbstractTableModel;

import m801.business_objects.Relationship;

import java.util.List;

//Handles the table funcationalities
public abstract class TableValues extends AbstractTableModel
{
	//Count the number of rows
	public int getRowCount() {return _values.length;}
	//Count the number of columns
	public int getColumnCount() {return _values[0].length;}
	//Get the olumn name
	public String getColumnName(int index) {return columnNames[index];}
	//Get the value for a given row and column
	public Object getValueAt(int row, int column) {return _values[row][column];}

	//Get all the values
	public Object[][] getValues()
	{
		return _values;
	}
	
	//Get all the relationships
	public List<Relationship> GetRelationshipToRemove(){return null;}
	
	//Set the values in the grid
	protected void setValues(Object[][] values)
	{
		_values = values;
	}
	
	//Set the value for a given row and column
	public void setValueAt(Object value, int row, int column)
	{
		_values[row][column] =value;
	}
	
	//Indicates whether the cell is editable
	public boolean isCellEditable(int row, int column)
	{
		if (column == 1) 
			return true;
		
		return false;
	}
	
	public final static int POTENTIAL_REDUDANT_PATH = 0;
	public final static int REMOVE = 1;
	public final static int EQUVALENT_PATH = 2;
	public final static String[] columnNames = {"Potential Redundant Path","Remove", "Equivalent Path"};

	private Object[][] _values;

}
