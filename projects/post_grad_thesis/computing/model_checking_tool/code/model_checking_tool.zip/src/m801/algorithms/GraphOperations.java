package m801.algorithms;

import java.util.*;


import m801.algorithms.interfaces.IGraph;
import m801.algorithms.interfaces.IGraphOperation;
import m801.business_objects.Constraint;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;
import m801.logger.EntityRelationshipDiagramPlugin;
import m801.utils.SingleLinkedList;

import org.eclipse.core.runtime.IStatus;

public  abstract class GraphOperations implements IGraphOperation 
{
	//This is the constructor
	public GraphOperations()
	{
		_pathsRemoved = new ArrayList<String>();
	}
	
	//This method gest all the removed paths
	public static List<String> getAllRemovedPaths()
	{
		return _pathsRemoved;
	}
	//This methods gets the list of potential redundant relationships
	public abstract List<PotentialRedundantRelationship> getPotentialRedundantRelationships(	EntityRelationshipDiagram erd,
																								BooleanGraph booleanGraph, 
																								ElementGraph elementGraph);
	
	// This method removes partition(s) given a set of relationships to delete.
	public abstract  ElementGraph removePartition(ElementGraph elementGraph, String[] pathsToRemove);
	
	// This method removes partition(s) given a set of relationships to delete.
	public abstract  ElementGraph removeUnwantedPartition(	EntityRelationshipDiagram erd,
															BooleanGraph booleanGraph, 
															ElementGraph elementGraph);

	//This method creates a graph of order N
	public IGraph createGraphOrderN(int order, EntityRelationshipDiagram erd) throws Exception
	{
		ElementGraph gragh = null;
		BooleanGraph booleanGraph = (BooleanGraph)createInitialGraph (erd);
		
		if (order >2)
		{
			gragh = createNOrdereGraph(order, booleanGraph,erd);
			return gragh; 
		}
		
		return booleanGraph;
	}
	
	//This method clone an entity linked list
	public List<SingleLinkedList> cloneEntityLinkedLists(List<SingleLinkedList> entitySingleLinkedList)
	{
		if (entitySingleLinkedList!=null)
		{
			List<SingleLinkedList> entitySingleLinkedListClone = new ArrayList<SingleLinkedList>(entitySingleLinkedList.size());
			for (int i=0; i<entitySingleLinkedList.size(); i++)
				entitySingleLinkedListClone.add(entitySingleLinkedList.get(i));
			
			return entitySingleLinkedListClone;
		}
		
		return null;
	}
	
	//This method create the intial boolean graph			
	public IGraph createInitialGraph(EntityRelationshipDiagram erd) throws Exception
	{
		String fromName ="";
		String toName ="";
		//String name = "";
		int fromIndex =0;
		int toIndex =0;
		Constraint constraint = null;
		
		BooleanGraph graph = new m801.algorithms.BooleanGraph(erd.getEntities().size());
		for (Relationship relationship: erd.getRelationships())
		{
			//name = relationship.getName();
			fromName = relationship.getFrom().getEntityName();
			toName = relationship.getTo().getEntityName();
			fromIndex = erd.getEntityIndex(fromName);
			toIndex = erd.getEntityIndex(toName);
			constraint = new Constraint();
			constraint = erd.getConstraint(Constraint.createName(fromName, toName));
			addEdgeToGraph(graph, relationship, constraint,  fromIndex,toIndex);
		}
				
		return graph;
	}
		
	//This method gets the graph of degree N
	public ElementGraph getNDegreeGraph(IGraph booleanGraph, IGraph elementGraph, EntityRelationshipDiagram erd, int currentOrder)
	{
		int nVertices = booleanGraph.getVerticeSize();
		
		ElementGraph nDegreeGraph =null;
		ElementGraph currentGraph = null;
		
		//depending on whether the elementGraph is a Booleangraph or
		//an ElementGraph, nDegreeGraph will be instantiated differently... 
		if (elementGraph instanceof BooleanGraph)
			nDegreeGraph = new ElementGraph(nVertices);
		else
		{
			nDegreeGraph = (ElementGraph)elementGraph;
			currentGraph =  nDegreeGraph.clone();
		}
		
		//add an edge to the the graph
		nDegreeGraph = addEdgeToGraph(	nVertices,
										booleanGraph, 
										elementGraph,
										nDegreeGraph,	
										currentGraph,
										erd, 
										currentOrder);
				
		//return the new graph of degree n
		return nDegreeGraph;
	}
	
	//This method adds an edge to the graph
	protected abstract ElementGraph addEdgeToGraph(	int nVertices,
													IGraph booleanGraph, 
													IGraph elementGraph,
													ElementGraph nDegreeGraph,
													ElementGraph currentGraph,
													EntityRelationshipDiagram erd, 
													int currentOrder);
	
	
	//This method indicates whether the realtionships between two entites in the graph is unwanted, i.e.
	//1. it displays a recursive relatonship when this should not be the case in the initial bool matrix.
	//2. it displays a number of relationships between two entites that is greater than the one described in the inital bool matrix
	protected abstract boolean isUnwantedPartition (	Entity entityFrom, 
														Entity entityTo, 	
														EntityRelationshipDiagram erd,
														BooleanGraph booleanGraph,
														Partition partition);
	
	protected void addEdgeToGraph(ElementGraph graph,  int vertice1, int vertice2, Element element)
	{
		m801.algorithms.Edge edge = new m801.algorithms.Edge(vertice1,vertice2);
		graph.insert(edge, element);
	}
	
	//This method creates an Element that can be added as an edge to the graph
	protected Element createElement(	EntityRelationshipDiagram erd, 
										IGraph booleanGraph, 
										IGraph elementGraph,
										ElementGraph currentGraph,	
										Element element,
										List<Partition> partitions,	
										int p, int i, int k,
										int currentOrder)
	{
		Partition partition =  null;
		
		EntityLinkageInformation eli = (EntityLinkageInformation)booleanGraph.getElement(k,p);
		Boolean intialBoolValue  = edgeExists(eli);
		Boolean elementBoolValue = edgeExists(elementGraph.getElement(i,k));
		boolean isUnwantedPartition = true;
		boolean bFound =false;
		EntityLinkageInformation eli1 = null;
		EntityLinkageInformation eli2 = null;
		int countRel = 0;
		int u;
			
		//check whether there is an edge...
		if (intialBoolValue && elementBoolValue)
		{
			//get the path source entity
			Entity fromEntity = erd.getEntity(i);
			//get the path destination entity
			Entity toEntity = erd.getEntity(p);
			//get the entity to add to the compoased path
			Entity entity = erd.getEntity(k);
			
			countRel = EntityRelationshipDiagram.getNumberRelationshipBetweenTwoEntities(erd,fromEntity.getName(), entity.getName());
			if (countRel <= eli.getRelationshipsClone().size())
				countRel = 1;
			
			//this loop is necessary as there may be more than one relationship
			//between two entities.
			for (Relationship relationship: eli.getRelationshipsClone())
			{
				u = 0;
				
				//get entity and add it to the list
				if (currentOrder <= 2)
				{
					//this loop is required to take into account multiple relationships.
					while (u<countRel)
					{
						partition =  new Partition();
						
						eli2 = (EntityLinkageInformation)booleanGraph.getElement(i,k);
						if (eli2 !=null)
						{
								//there is no element in the nDegreeGraph yet... 
								//it is used for matrix of order 2
								partition = setPartition(erd,fromEntity,entity, toEntity, relationship);
								
								//this is a special case, when there is more than one relationship between two entities, 
								//but the fromEnity corresponds to the entityTo on the relationship, then this code
								//forces two relationships to be created, whithout this code, only one would be created
								eli1 = (EntityLinkageInformation)booleanGraph.getElement(i,p);
								if (eli1!=null)
								{
										if (
												(relationship.getTo().getEntityName().contentEquals(entity.getName()) &&
												relationship.getFrom().getEntityName().contentEquals(toEntity.getName()) )  ||
												(relationship.getFrom().getEntityName().contentEquals(entity.getName()) &&
												relationship.getTo().getEntityName().contentEquals(toEntity.getName()) )
											)
										{
											
											isUnwantedPartition = isUnwantedPartition (fromEntity, toEntity, erd, (BooleanGraph)booleanGraph, partition);
											if (! isUnwantedPartition)
											{
												//add entity to the element
												element.addPartition(partition);
											}
											
											bFound =true;
										}
								}
								
								//this is the 'normal' code path... without the hack explained abve
								if (bFound == false)
								{						
									isUnwantedPartition = isUnwantedPartition (fromEntity, toEntity, erd, (BooleanGraph)booleanGraph, partition);
									if (! isUnwantedPartition)
									{
										//add entity to the element
										element.addPartition(partition);
									}
								}
							}
							u++;
						}
				}
				else
				{
					//there is an element in the nDegreeGraph... 
					//for any case of martrix 3 included and above..
					partitions  = currentGraph.clone().getElement(i,/*k*/ p).getPartitions();	
					
					SingleLinkedList entitySingleLinkedList =null;
					Signature signature = null;
					List<Relationship> relationships = null;  

					for (int m=0; m<partitions.size(); m++)
					{
						if (partitions.get(m)!=null)
						{
							partition = new Partition();
							
							//get all the relationships between the entityFrom and the first entity in the list
							
							String firstEntitylist =((EntityLinkageInformation)partitions.get(m).getEntityList().getNode(0)).getEntity().getName(); 
							relationships = EntityRelationshipDiagram.getRelationshipBetweenTwoEntities(erd, /*fromEntity.getName()*/ entity.getName(),firstEntitylist);
							
							if (relationships !=null || relationships.size() > 0)
							{
								//that takes care of multiple relationships
								for (Relationship rel: relationships)
								{
									entitySingleLinkedList = partitions.get(m).getEntityListClone();
									eli1 = createEntityLinkageInformation(erd, entity, rel);
									entitySingleLinkedList.insertAtFront(eli1);
									partition.setEntityList(entitySingleLinkedList);
									
									isUnwantedPartition = isUnwantedPartition (fromEntity, toEntity, erd, (BooleanGraph)booleanGraph, partition);
									if (! isUnwantedPartition)
									{
										
										signature = createSignature(	erd, 
																		fromEntity,
																		toEntity,
																		entitySingleLinkedList);
										partition.setSignature(signature);
										
										//add entity to the element
										element.addPartition(partition);
									}
								}
							}
												
						}
					}
				}
			}
		}
		
		return element;
	}
		
	//This method sets the partition
	protected  Partition setPartition(	EntityRelationshipDiagram erd,
									Entity fromEntity, 
									Entity entity, 
									Entity toEntity,
									Relationship relationship)
	{
		//instantiate the required objects
		Partition partition = new Partition();
		SingleLinkedList entitySingleLinkedList = new SingleLinkedList();
		Signature signature = null;
		
		EntityLinkageInformation eli = createEntityLinkageInformation(erd, entity, relationship);
			
		//insert the	 entity in the list
		entitySingleLinkedList.insertAtFront(eli);
		

		signature = createSignature(	erd, 
										fromEntity,
										toEntity,
										entitySingleLinkedList);
		
		//add objects to the partition
		partition.setEntityList(entitySingleLinkedList);
		partition.setSignature(signature);
		
		return partition;	
	}
	
	//This method creates the signature
	protected Signature createSignature(	EntityRelationshipDiagram erd,
										Entity fromEntity, 
										Entity toEntity,
										SingleLinkedList entitySingleLinkedList)
	{
		Signature signature =null;
		//compose the signature
		try
		{
			signature = new Signature();
			signature = SignatureComposition.calculate(	erd, 
													    fromEntity,
													    entitySingleLinkedList, 
													    toEntity);
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		
		return signature;
	}
	
	//This method creates a graph of order N
	private ElementGraph createNOrdereGraph(int order, IGraph booleanGraph, EntityRelationshipDiagram erd) throws Exception
	{
		
		int currentOrder = 2;
		ElementGraph nDegreeGraph = null;
		
		while (currentOrder <= order)
		{
			if (currentOrder <= 2)
				nDegreeGraph = getNDegreeGraph(booleanGraph, booleanGraph, erd, currentOrder);
			else
				nDegreeGraph = getNDegreeGraph(booleanGraph, (IGraph)nDegreeGraph.clone(), erd, currentOrder);
			
			currentOrder++;
		}
			
		return nDegreeGraph;
	}
	
	//This method creates an EntityLinkageInformation object
	private EntityLinkageInformation createEntityLinkageInformation(	EntityRelationshipDiagram erd,
																		Entity entity, 
																		Relationship relationship)
	{
		//get constraint
		Constraint constraint = erd.getConstraint(Constraint.createName(relationship.getFrom().getEntityName(), relationship.getTo().getEntityName()));
		
		EntityLinkageInformation eli = new EntityLinkageInformation();
		eli.setEntity(entity.Clone());
		eli.addRelationship(relationship);
		eli.addConstrainst(constraint);
		
		return eli;
	}
	
	//This method adds an edge to the graph
	private void addEdgeToGraph(	BooleanGraph graph, 
									Relationship relationship,
									Constraint constraint,
									int vertice1, int vertice2)
	{
		//int countRelationships =0;
		m801.algorithms.Edge edge = new m801.algorithms.Edge(vertice1,vertice2);
		
		EntityLinkageInformation eli = new EntityLinkageInformation();
		eli.addRelationship(relationship);
		eli.addConstrainst(constraint);
		
		graph.insert(edge, eli);
	}
	
	//This method indicates whether a relationship exists between two entities
	private boolean edgeExists (Object oValue)
	{
		if (oValue == null)
			return false;
		
		if (oValue instanceof EntityLinkageInformation)
			return edgeExists((EntityLinkageInformation) oValue);
		else
			return edgeExists((Element) oValue);
	}
	
	//This method indicates whether a edge exists
	private boolean edgeExists(EntityLinkageInformation rli)
	{
		if (rli == null)
			return false;
		
		if (rli.getRelationships().size() == 0)
			return false;
		
		return true;
	}
	
	//This method indicates whether a relationship exists between two entities
	private boolean edgeExists(Element element)
	{
		if (element == null)
			return false;
		
		if (element.getPartitions().size() == 0)
			return false;
		
		return true;
	}
	
	protected static List<String> _pathsRemoved =null;
}
