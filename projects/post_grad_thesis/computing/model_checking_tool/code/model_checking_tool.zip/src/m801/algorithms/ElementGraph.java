package m801.algorithms;

import m801.algorithms.interfaces.IGraph;
import m801.logger.EntityRelationshipDiagramPlugin;

import org.eclipse.core.runtime.IStatus;

public class ElementGraph implements IGraph
{
	private int _vertices =0;
	private int _edges =0;
	private Element _adj[][] =null;
	
	//This is the constructor
	public ElementGraph(int vertices)
	{
		_vertices  = vertices;
		_edges = 0;
		_adj = new Element[vertices][vertices];
	}
				
	//This method gets the number of vertices from a graph element
	public int getVerticeSize()
	{
		return _vertices;
	}
	
	//This method gets the number of edges from a graph element
	public int getEdgeSize()
	{
		return _edges;
	}
	
	//This method gets the size from a graph element
	public int size()
	{
		return getVerticeSize() * getEdgeSize();
	}
	
	//This method inserts an edge to an elementGraph object
	public void insert(Edge e, Object oValue)
	{
		int vertice1 = e.getVertice1();
		int vertice2 = e.getVertice2();
		
		try
		{
			_adj[vertice1][vertice2] = (Element)oValue;
			//_adj[vertice2][vertice1] = (Element)oValue;
		}
		catch (Exception exception)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, exception.getMessage(), exception);
		}
	}
	
	//This method inserts elements to a graph element
	public void insert(Element[][] elements)
	{
		_adj = elements;
	}
	
	//This method gets an element from a graph element
	public Element getElement(int vertice1, int vertice2)
	{
		return (Element) _adj[vertice1][vertice2];
	}	
	
	//This method clones the elementGraph object
	public ElementGraph clone()
	{
		ElementGraph elementGraph = new ElementGraph(this.getVerticeSize());
		elementGraph.insert(cloneElements());
				
		return elementGraph;
	}
	
	//This method clones elements
	private Element[][] cloneElements()
	{
		Element adj[][] = null;
		
		if (_adj!=null)
		{
			adj = new Element[_adj.length][_adj.length];
			
			for (int i=0; i<_adj.length; i++)
			{
				for (int j=0; j<_adj.length; j++)
				{
					if (_adj[i][j]!=null)
						adj[i][j] = (Element)_adj[i][j];
				}
			}
		}
		
		return (Element[][]) adj;		
	}
}