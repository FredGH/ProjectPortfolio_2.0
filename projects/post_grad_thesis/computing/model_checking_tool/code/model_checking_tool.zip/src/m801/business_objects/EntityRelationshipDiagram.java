package m801.business_objects;

import java.util.ArrayList;
import java.util.List;

import m801.logger.EntityRelationshipDiagramPlugin;
import m801.utils.Globals;

import org.eclipse.core.runtime.IStatus;

//This class represents the ERD object
public class EntityRelationshipDiagram 
{	
	//The constructor
	public EntityRelationshipDiagram()
	{
		_name = "";
		_type = "ERD";
		_relationships = new ArrayList<Relationship>(); 
		_constraints = new ArrayList<Constraint>();
		_entities = new ArrayList<Entity>();
		
	}
	
	//Get the number of relationship between 2 entities
	public static int getNumberRelationshipBetweenTwoEntities(EntityRelationshipDiagram erd, String fromEntity, String toEntity)
	{
		int count =0;
		for (Relationship rel:erd.getRelationships())
		{
			if ( (rel.getFrom().getEntityName().contentEquals(fromEntity)&& 
				 rel.getTo().getEntityName().contentEquals(toEntity)) ||
				 (rel.getFrom().getEntityName().contentEquals(toEntity)&& 
				 rel.getTo().getEntityName().contentEquals(fromEntity)))
				 {
					count++;
				 }
			
		}
		
		return count;
	}
	
	//Get the relationships between 2 entities
	public static List<Relationship> getRelationshipBetweenTwoEntities(EntityRelationshipDiagram erd, String fromEntity, String toEntity)
	{
		List<Relationship> relationships = new ArrayList<Relationship>();  
		for (Relationship rel:erd.getRelationships())
		{
			if ( (rel.getFrom().getEntityName().contentEquals(fromEntity)&& 
				 rel.getTo().getEntityName().contentEquals(toEntity)) ||
				 (rel.getFrom().getEntityName().contentEquals(toEntity)&& 
				 rel.getTo().getEntityName().contentEquals(fromEntity)))
				 {
					relationships.add(rel);
				 }
			
		}
		
		return relationships;
	}
	
	//Set the ERD name
	public void setName(String name)
	{
		_name = name;
	}
	
	//Get the ERD name
	public String getName()
	{
		return _name;
	}
	
	//Set the ERD type
	public void setType(String modelType)
	{
		_type = modelType;
	}
	
	//Get the ERD type
	public String getType()
	{
		return _type;
	}
	
	//Add an entity
	public void addEntity(Entity entity)
	{
		_entities.add(entity);
	}
	
	//Add a relationship
	public void addRelationship(Relationship relationship)
	{
		_relationships.add(relationship);
	}
	
	//Add a constraint
	public void addConstraints(Constraint constraint)
	{
		_constraints.add(constraint);
	}
	
	//Get the list of entities
	public List<Entity> getEntities()
	{
		return _entities;
	}

	//Get the entity for a given index
	public int getEntityIndex(String entityName) throws Exception
	{
		for(int i=0; i< _entities.size(); i++)
		{
			if (_entities.get(i).getName().equalsIgnoreCase(entityName))
				return i;
		}
		
		Globals.checkIndexValidatity(Globals.NOT_FOUND);
		
		return Globals.NOT_FOUND;
	}
	
	//Get the entity for a given entity name
	public Entity getEntity(String entityName) throws Exception
	{
		Entity entity = null;
		
		for(int i=0; i< _entities.size(); i++)
		{
			if (_entities.get(i).getName().equalsIgnoreCase(entityName))
			{
				entity = _entities.get(i);
				return entity;
			}
		}
		
		if (entity == null)
			throw new Exception("the entity cannot be found");
		
		return null;
	}
	
	//Get the entity for a given index
	public Entity getEntity(int entityIndex) 
	{
		try
		{
			return _entities.get(entityIndex);
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		
		return null;
	}
	
	//Get the constraint for a given constraint name
	public Constraint getConstraint(String constraintName)
	{
		try
		{
			for (int i=0; i<_constraints.size(); i++ )
			{
				if (_constraints.get(i).contentEquals(constraintName))
					return _constraints.get(i);
			}
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		
		return null;
	}
	
	//Get the list of relationships
	public List<Relationship> getRelationships()
	{
		return _relationships;
	}
	
	//Get the list of constraints
	public List<Constraint> getConstraints()
	{
		return _constraints;
	}

	//Object representation to String
	public String toString()
	{
		String message ="";
		for (Entity entity: _entities)
			message +=entity.toString();
		
		for (Relationship relationship: _relationships)
			message +=relationship.toString();
		
		for (Constraint constraint: _constraints)
			message +=constraint.toString();
		
		return message;
	}
	

	private String  _name;
	private String  _type;
	private List<Entity> _entities;
	private List<Relationship> _relationships;
	private List<Constraint> _constraints;
}