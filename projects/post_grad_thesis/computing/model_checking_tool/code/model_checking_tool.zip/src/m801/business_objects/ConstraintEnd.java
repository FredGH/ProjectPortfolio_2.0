package m801.business_objects;

import java.util.List;

//This class represents the constraint End object
public class ConstraintEnd 
{
	//The constructor
	public ConstraintEnd()
	{
		_entity = "";
		_direction ="";
		_constraintEndAttributes =null;
	}
	
	//Set the contraint entity end name
	public void setEntityName(String entity)
	{
		_entity = entity;
	}
	
	//Get the contraint entity end name
	public String getEntityName()
	{
		return _entity;
	}
	
	//Set the contraint direction
	public void setDirection(String direction)
	{
		_direction = direction;
	}
	
	//Set the contraint direction
	public String getDirection()
	{
		return _direction;
	}
	
	//Set the list of attributes
	public void setAttributes(List<ConstraintEndAttribute> constraintEndAttributes)
	{
		_constraintEndAttributes = constraintEndAttributes;
	}
	
	//Get the list of attributes
	public String getAttributesToString()
	{
		String attributeList= "";
		ConstraintEndAttribute constraintEndattribute;
		for (int i=0; i<getAttributes().size(); i++)
		{
			constraintEndattribute = getAttributes().get(i);
			if (i < getAttributes().size()-1)
				attributeList += constraintEndattribute.getName() + ",";
			else
				attributeList += constraintEndattribute.getName();
		}
		
		return attributeList;
	}
	
	//Get the list of attributes
	public List<ConstraintEndAttribute> getAttributes()
	{
		return _constraintEndAttributes;
	}
	
	private String _entity;
	private String _direction;
	private List<ConstraintEndAttribute> _constraintEndAttributes;
}

