package m801.algorithms;

import java.util.List;

import m801.business_objects.Attribute;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;


//This is shortcut abstract class
public abstract class Shortcut 
{	
	//The constructor
	public Shortcut(	EntityRelationshipDiagram erd,
						List<Relationship> relationships,
						Entity fromEntity,
						List<Attribute> fromEntityAtttibutesPK,
						List<Attribute> fromEntityAtttibutes,
						Entity midEntity,
						List<Attribute> midEntityAtttibutesPK,
						List<Attribute> midEntityAtttibutes,
						Entity toEntity,	
						List<Attribute> toEntityAtttibutesPK,
						List<Attribute> toEntityAtttibutes)
	{
		_erd = erd;
		_relationships = relationships;
		_fromEntity = fromEntity ;
		_fromEntityAtttibutesPK = fromEntityAtttibutesPK;
		_fromEntityAtttibutes = fromEntityAtttibutes;
		_midEntity = midEntity;
		_midEntityAtttibutesPK = midEntityAtttibutesPK;
		_midEntityAtttibutes = midEntityAtttibutes;
		_toEntity = toEntity;
		_toEntityAtttibutesPK = toEntityAtttibutesPK;
		_toEntityAtttibutes = toEntityAtttibutes;
	}
	
	//Get the potential relationships in the ERD
	public List<Relationship> getPotentialRedundantRelationship ()
	{
	
		//FromEntity To ToEntity
		boolean hasFromToSC = hasShortCut();
		
		//FromEntity To ToEntity
		boolean hasToFromSC = hasShortCut();
		
		//get the relationships name from the erd
		if (hasFromToSC ==true || hasToFromSC == true)
		{
			for(Relationship relationship: _erd.getRelationships())
			{
				if (	relationship.getFrom().getEntityName().contentEquals(_fromEntity.getName()) &&
						relationship.getTo().getEntityName().contentEquals(_toEntity.getName()) == true)
				{
					if (!_relationships.contains(relationship))
						_relationships.add(relationship);	
				}
		
			}
		}
		
		return _relationships;
	}
	
	//This method checks the existence of a vertical shortcut in the 3 entity cycle
	protected boolean hasShortCut()
	{
			boolean isAttShared =  isAttributeSharedInAllEntities();
			
			boolean hasInclusion = hasInclusionConstraint();
			
			return isAttShared && hasInclusion;
	}
	
	//This method check whhether the PK attributes are shared accross all entities in the 3 entity cycle
	protected abstract boolean isAttributeSharedInAllEntities();
	
	//This method indicates whether there is an inclusion constraint between two relationships
	protected abstract boolean hasInclusionConstraint();
	
	
	protected EntityRelationshipDiagram _erd;
	protected List<Relationship> _relationships;
	protected Entity _fromEntity;
	protected List<Attribute> _fromEntityAtttibutesPK;
	protected List<Attribute> _fromEntityAtttibutes;
	protected Entity _midEntity;
	protected List<Attribute> _midEntityAtttibutesPK;
	protected List<Attribute> _midEntityAtttibutes;
	protected Entity _toEntity;
	protected List<Attribute> _toEntityAtttibutesPK;
	protected List<Attribute> _toEntityAtttibutes;
}
