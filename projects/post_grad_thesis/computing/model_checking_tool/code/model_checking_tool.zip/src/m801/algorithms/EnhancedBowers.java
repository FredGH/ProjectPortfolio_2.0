package m801.algorithms;

import java.util.ArrayList;
import java.util.List;


import m801.algorithms.interfaces.IGraph;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;
import m801.logger.EntityRelationshipDiagramPlugin;

import org.eclipse.core.runtime.IStatus;


public class EnhancedBowers extends GraphOperations
{
	//This methods gets the list of potential redundant relationships
	public List<PotentialRedundantRelationship> getPotentialRedundantRelationships(	EntityRelationshipDiagram erd,
																					BooleanGraph booleanGraph, 
																					ElementGraph elementGraph)
	{
		Partition partition = null;
		List<String> partNames = new ArrayList<String>();
		List<Relationship> boolRelationships = null;
		PotentialRedundantRelationship prr =null;
		Entity fromEntity = null;
		Entity toEntity = null;
		List<PotentialRedundantRelationship> potentialRedundantRelationships = new ArrayList<PotentialRedundantRelationship>();
		Boolean bContinue = true;	
		
		for (int i =0; i <elementGraph.getVerticeSize(); i++)
		{
			for (int j =0; j <elementGraph.getVerticeSize(); j++)
			{
				if (elementGraph.getElement(i, j) !=null)
				{
					if (elementGraph.getElement(i, j).getPartitions() !=null)
					{
						fromEntity = erd.getEntity(i);
						toEntity = erd.getEntity(j);
						
						for (int k = 0; k< elementGraph.getElement(i, j).getPartitions().size(); k++)
						{
							partition = elementGraph.getElement(i, j).getPartitions().get(k);
							
							if (partition !=null)
							{
								//in case of multiple relationships
								if (booleanGraph.getElement(i, j) != null)
								{		
									boolRelationships = booleanGraph.getElement(i, j).getRelationships();
									if (boolRelationships != null)
									{
										for(Relationship boolRelationship: boolRelationships)
										{
											//ensure the path that is potentially redundant is not in the list of equivalent paths.
											for (int m = 0; m< partition.getEntityList().size(); m++)
											{
												EntityLinkageInformation eli = ((EntityLinkageInformation)partition.getEntityList().getNode(m));
												if (eli.getRelationships().get(0).getName().contentEquals(boolRelationship.getName()))
												{
													bContinue = false;
													break;
												}
											}
											
											if (bContinue == true && SignatureComposition.SignatureIsEquivalent(boolRelationship,partition) == true)
											{
												//just to avoid repetition
												if (!partNames.contains(partition.toString()))
												{
													partNames.add(partition.toString());
													
													prr =  new PotentialRedundantRelationship();
													prr.setRelationship(boolRelationship);
													prr.setPartition(partition);
													prr.setFromEntity(fromEntity);
													prr.setToEntity(toEntity);
													potentialRedundantRelationships.add(prr);
												}
											}

											bContinue = true;
										}
									}
								}
							}
						}
					}
				}
			}
		}
		
		return potentialRedundantRelationships;
	}		

	// This method removes partition(s) given a set of relationships to delete.
	public  ElementGraph removePartition(ElementGraph elementGraph, String[] pathsToRemove)
	{
		//remove the selected paths by the user...
		Partition partition = null;
		if (pathsToRemove != null)
		{
			for (int i =0; i <elementGraph.getVerticeSize(); i++)
			{
				for (int j =0; j <elementGraph.getVerticeSize(); j++)
				{
					for (int k = 0; k< elementGraph.getElement(i, j).getPartitions().size(); k++)
					{
						partition = elementGraph.getElement(i, j).getPartitions().get(k);
						if (partition !=null)
						{
							for (int l = 0; l< partition.getEntityList().size(); l++)
							{
								for (Relationship relationship:((EntityLinkageInformation)partition.getEntityList().getNode(l)).getRelationships())
								{
									for (String pathToRemove: pathsToRemove)
									{
										if (pathToRemove !=null)
										{
											if (relationship.getFrom().getEntityName().contentEquals(m801.utils.UI.getFromEntityName(pathToRemove)) == true &&
												relationship.getTo().getEntityName().contentEquals(m801.utils.UI.getToEntityName(pathToRemove)) == true &&
												relationship.getName().contentEquals(m801.utils.UI.getRelationshipName(pathToRemove)) == true) 
											{
												elementGraph.getElement(i, j).getPartitions().set(k, null);	
											}
										}
									}
								}
							}
						}
					}
				}
			}
		}
		
		//add the pathsToRemove to the static list... So that at any point in time, we know
		//what path have been removed to far.
		if (pathsToRemove !=null && pathsToRemove.length > 0)
		{
			for(String pathToRemove: pathsToRemove)
				if (!_pathsRemoved.contains(pathToRemove))
					_pathsRemoved.add(pathToRemove);
		}
		
		return elementGraph; 
	}
	
	// This method removes partition(s) given a set of relationships to delete.
	public  ElementGraph removeUnwantedPartition(	EntityRelationshipDiagram erd,
													BooleanGraph booleanGraph, 
													ElementGraph elementGraph)
	{
		Partition partition = null;
		Entity entityFrom = null;
		Entity entityTo = null;
		boolean  isUnwanted = false;
		
		for (int i =0; i <elementGraph.getVerticeSize(); i++)
		{
			for (int j =0; j <elementGraph.getVerticeSize(); j++)
			{
				for (int k = 0; k< elementGraph.getElement(i, j).getPartitions().size(); k++)
				{
					partition = elementGraph.getElement(i, j).getPartitions().get(k);
					if (partition !=null)
					{
						
						entityFrom = erd.getEntity(i);
						entityTo = erd.getEntity(j);
						isUnwanted = isUnwantedPartition (entityFrom, entityTo, erd, booleanGraph, partition);
						
						if (isUnwanted)
							elementGraph.getElement(i, j).getPartitions().set(k, null);						
					}
				}
			}
		}
		
		return elementGraph; 
	}
	
	//This method adds an edge to the graph
	protected ElementGraph addEdgeToGraph(	int nVertices,
											IGraph booleanGraph, 
											IGraph elementGraph,
											ElementGraph nDegreeGraph,
											ElementGraph currentGraph,
											EntityRelationshipDiagram erd, 
											int currentOrder)
	{
		Element element = null;
		List<Partition> partitions =null;
		
		for (int p =0; p< nVertices; p++)
		{	
			for(int i=0; i<nVertices; i++)
			{
				partitions = new ArrayList<Partition>(); 
				element =  new Element();
				
				for(int k=0; k<nVertices; k++)
				{
					//create an element
					element = createElement(	erd, 
												booleanGraph, 
												elementGraph,
												currentGraph,	
												element,
												partitions,	
												p, i, k,
												currentOrder);	
				}
				
				//add the element to the graph
				addEdgeToGraph(nDegreeGraph,i,p, element);
			}
		}
		
		return nDegreeGraph;
	}
	
	//This method indicates whether the realtionships between two entites in the graph is unwanted, i.e.
	//1. it displays a recursive relatonship when this should not be the case in the initial bool matrix.
	//2. it displays a number of relationships between two entites that is greater than the one described in the inital bool matrix
	protected boolean isUnwantedPartition (	Entity entityFrom, 
											Entity entityTo, 	
											EntityRelationshipDiagram erd,
											BooleanGraph booleanGraph,
											Partition partition)
	{
		String from = "";
		String to = "";
		String minusTwoEntity = "";
		String minusOneEntity ="";
		int nbBoolRelationships = 0;
		List<String> graphKeys = new ArrayList<String>();
		int indexFrom = 0;
		int indexTo = 0;
		Entity currEntity = null;
		EntityLinkageInformation eli =null;
		
		for (int i = 0; i< partition.getEntityList().size(); i++)
		{
			graphKeys.clear();

			currEntity = ((EntityLinkageInformation)partition.getEntityList().getNode(i)).getEntity();
						
			//1. Remove looping back relationships and 1 case of recursive relationships
			if ( i == 0 && partition.getEntityList().size() == 1)
			{
				try
				{
					from 		= entityFrom.getName();
					indexFrom 	= erd.getEntityIndex(from);
					to 			= ((EntityLinkageInformation)partition.getEntityList().getNode(i)).getEntity().getName();;
					indexTo		= erd.getEntityIndex(to);
					
					eli = (EntityLinkageInformation) booleanGraph.getElement(indexFrom, indexTo);
					if (eli != null)
						nbBoolRelationships = eli.getRelationships().size();
					
					//case where the entityFrom and entityTo are the same
					if (from.contentEquals(entityTo.getName()))
					{
						//case where the entityFrom and the first entity in the list are not the same
						if (!from.contentEquals(to) /*&& getNumberOfRelationship (booleanGraph, indexFrom, indexTo) <= 1*/)
								return true;
						else
						{
							//case where the entityFrom and the first entity in the list are the same
							//but there is no recursive relationship
							if (nbBoolRelationships == 0 /*&& getNumberOfRelationship (booleanGraph, indexFrom, indexTo) <= 1*/)
								return true;
						}
					}
				}
				catch (Exception e)
				{
					EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
				}
			}
			else if ( i>= 1 )
			{			
				if ( i == 1 )
					//start the comparison at the position 1, and compare with the entityFrom
					minusTwoEntity = entityFrom.getName().toString();
				else
					//the comparison is now between any entity and the one at the position -2
					minusTwoEntity = ((EntityLinkageInformation)partition.getEntityList().getNode(i-2)).getEntity().getName();

				if (currEntity.getName().contentEquals(minusTwoEntity))
					return true; // a loop back exists
				
				//compare the entityTo against the last one in the list
				if (i == partition.getEntityList().size() -1)
				{
					minusOneEntity = ((EntityLinkageInformation)partition.getEntityList().getNode(i-1)).getEntity().getName();
					
					if (minusOneEntity.contentEquals(entityTo.getName()))
						return true; //a loop back exists
				}
			}
			
			//2. remove unwanted recursive relationships
			boolean bUnwantedRecursive = false;

			from 		= entityFrom.getName();
			to 			= entityTo.getName();
			
			//check whether the cycle (from entityFrom to entityTo) is recursive. If this is not the case,
			//then remove the partition
			if (from.contentEquals(to))
			{
				
				bUnwantedRecursive =  	removeUnwantedRecursivePartition(	from, to, 
										erd, 
										partition,
										booleanGraph);
				
				return bUnwantedRecursive;
			
			}
			else
			{
				if (i == 0)
				{
					//comparison of the entityFrom and the first one in the list
					from 		= entityFrom.getName();
					to 			= ((EntityLinkageInformation)partition.getEntityList().getNode(i)).getEntity().getName();
					
					bUnwantedRecursive =  removeUnwantedRecursivePartition(	from, to, 
																			erd, 
																			partition,
																			booleanGraph);
				}
				else if (i == partition.getEntityList().size() -1)
				{
					//comparison of the entityTo and the last one in the list
					from 		= ((EntityLinkageInformation)partition.getEntityList().getNode(i)).getEntity().getName();
					to 			= entityTo.getName();
					
					bUnwantedRecursive =  removeUnwantedRecursivePartition(	from, to, 
																			erd, 
																			partition,
																			booleanGraph);
					
				}
				else
				{
					//comparison between entity e and e-1 in the list
					//comparison of the entityFrom and the first one in the list
					from 		= ((EntityLinkageInformation)partition.getEntityList().getNode(i-1)).getEntity().getName();
					to 			= ((EntityLinkageInformation)partition.getEntityList().getNode(i)).getEntity().getName();
					
					bUnwantedRecursive =  removeUnwantedRecursivePartition(	from, to, 
																			erd, 
																			partition,
																			booleanGraph);
				}
				
				if (bUnwantedRecursive)
					return true;
			}
		}
		return false;
	}
	
	//This methd removes unwanted recursive partitions
	private boolean removeUnwantedRecursivePartition(	String from, String to, 
														EntityRelationshipDiagram erd, 
														Partition partition,
														BooleanGraph booleanGraph)
	{
		try
		{
			int nbBoolRelationships = 0;
			int indexFrom 	= erd.getEntityIndex(from);
			int indexTo		= erd.getEntityIndex(to);
			
			EntityLinkageInformation eli = (EntityLinkageInformation) booleanGraph.getElement(indexFrom, indexTo);
			if (eli != null)
				nbBoolRelationships = eli.getRelationships().size();
			
			if (nbBoolRelationships == 0)
				return true;
		
		}
		catch (Exception e)
		{
			EntityRelationshipDiagramPlugin.log(IStatus.ERROR, e.getMessage(), e);
		}
		
		return false;
		
	}
}