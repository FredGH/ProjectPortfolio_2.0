package m801.utils;

//This class derive from the RuntimeException class and provide a custom expection handling for Empty List
public class EmptyListException extends RuntimeException {

	
	public EmptyListException( String name )
	{
		super( "The " + name + " is empty" );
	}
	
	//this is enforced by the comopiler... I have selected a value, but could be any long
	static final long serialVersionUID = 131416; 
}

