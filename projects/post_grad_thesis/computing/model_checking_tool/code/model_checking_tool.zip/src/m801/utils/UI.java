package m801.utils;

import java.util.List;
import java.util.ArrayList;

import m801.algorithms.EntityLinkageInformation;
import m801.algorithms.Partition;
import m801.algorithms.SignatureComposition;
import m801.business_objects.Entity;
import m801.business_objects.EntityRelationshipDiagram;
import m801.business_objects.Relationship;

//Specialise in the UI data rendering
public class UI 
{
	//Create a path given a fromEntity, a parition and a toEntity
	public static List<String> getPathName(String sourceRelationshipName, Entity startEntity, Partition partition, EntityRelationshipDiagram erd)
	{
		List<String> pathsRemoved =  new ArrayList<String>();
		pathsRemoved.add(NO_PATH_REMOVE);
		
		
		return getPathName(sourceRelationshipName, startEntity, partition, pathsRemoved, erd );
	}
	
	//Create a path given a fromEntity, a parition and a toEntity
	public static List<String> getPathName(	String sourceRelationshipName,
											Entity startEntity,
											Partition partition, 
											List<String> pathsRemoved, 
											EntityRelationshipDiagram erd)
		{
		EntityLinkageInformation eli = null;
		String endEnt ="";
		String fromEntity =  "";
		String toEntity = "";
		String startEnt = "";
		String currentPartitionRel ="";
		List<String> paths = new ArrayList<String>();
		
		if (partition.getEntityListClone() !=null && partition.getEntityListClone().size() > 0)
		{
			startEnt = startEntity.getName();
			endEnt = 	getEndEntityName(partition);
			
			for (int i =0; i< partition.getEntityListClone().size(); i++ )
			{
				eli = (EntityLinkageInformation)(partition.getEntityListClone().getNode(i));
				
				//build path between the start and from entities.. 
				if (i == 0)
				{
					fromEntity = startEnt;
					toEntity = eli.getEntity().getName();/*eli.getRelationships().get(0).getFrom().getEntityName();*/
					
					///get the list of paths existing between the from and to Entities
					for(Relationship relationship:erd.getRelationships())
					{
						//get the relationship between two entitites
						if ( (relationship.getFrom().getEntityName().contentEquals(fromEntity) && 
							 relationship.getTo().getEntityName().contentEquals(toEntity)) ||
							 (relationship.getFrom().getEntityName().contentEquals(toEntity) && 
							 relationship.getTo().getEntityName().contentEquals(fromEntity)))
						{
							currentPartitionRel = relationship.getName();
							break;
						}
					}
					
					paths = pathBuilder(startEnt,
										endEnt,
										fromEntity, 
										toEntity,
										currentPartitionRel,	
										pathsRemoved,
										paths,
										erd,
										partition,
										true);
				}
				
				//build path between the from and to entities...
				fromEntity = eli.getRelationships().get(0).getFrom().getEntityName();
				toEntity = eli.getRelationships().get(0).getTo().getEntityName();
				currentPartitionRel = eli.getRelationships().get(0).getName();
				
				paths = pathBuilder(startEnt,
									endEnt,
									fromEntity, 
									toEntity,	
									currentPartitionRel,
									pathsRemoved,
									paths,
									erd, 
									partition,
									false);
			}
		}
		
		return paths;
	}
	
	//Get the entity name given a partition
	private static String getEndEntityName(Partition partition)
	{
		String endEnt ="";
		
		EntityLinkageInformation endEli = ((EntityLinkageInformation)(partition.getEntityListClone().getNode(partition.getEntityListClone().size()-1)));
		Relationship endRelationship = endEli.getRelationships().get(0);
		Entity endEntity = endEli.getEntity();
		
		if (endRelationship.getFrom().getEntityName().contentEquals(endEntity.getName()))
			endEnt = endRelationship.getTo().getEntityName();
		else
			endEnt = endRelationship.getFrom().getEntityName();
		
		return endEnt;
	}
	
	//This method contains the logic to create a long path between a start and a to entity
	//depending on the number of relationships between entities.
	private static List<String> pathBuilder(	String startEnt,
												String endEnt,
												String fromEntity, 
												String toEntity,
												String currentPartitionRel,
												List<String> pathsRemoved,
												List<String> paths,
												EntityRelationshipDiagram erd,
												Partition partition,
												boolean bForce)
	{
		List<String> finalPaths = new ArrayList<String>();
		List<String> tempPaths = new ArrayList<String>();
		String relationshipName = "";
		
		///get the list of paths existing between the from and to Entities
		for(Relationship relationship:erd.getRelationships())
		{	
			//get the relationship between two entitites
			if ( (relationship.getFrom().getEntityName().contentEquals(startEnt) && 
				 relationship.getTo().getEntityName().contentEquals(endEnt)) ||
				 (relationship.getFrom().getEntityName().contentEquals(endEnt) && 
				 relationship.getTo().getEntityName().contentEquals(startEnt)))
			{
				//check partition has the same signature than the relationship
				//bForce flag used to force the creation of a path (this is necessary for the first sub path of 
				//a path between the start Entity and the entityFrom. 
				if (SignatureComposition.SignatureIsEquivalent(relationship, partition) == true || bForce == true)
				{
					//relationshipName = relationship.getName();
					relationshipName = currentPartitionRel;					

					if (!tempPaths.contains(getPathName(fromEntity,relationshipName, toEntity)))
					{
						if (pathsRemoved.get(0).contentEquals(NO_PATH_REMOVE))
						{
							tempPaths.add(getPathName(fromEntity,relationshipName, toEntity));	
						}
						else
						{
							//paths have been removed...
							for (String removedPaths: pathsRemoved)
							{
								//if the relationship has been removed between fromEntity and toEntity, then 
								// the entire path frome the start to the end entity on this relationship 
								//cannot exist.
								if (relationshipName.contentEquals(getRelationshipName(removedPaths)))
								{
									//the relationships does not get added...
								}
								else
								{
									//The relationship has not been removed, continue building the path... 
									tempPaths.add(getPathName(fromEntity,relationshipName, toEntity));
								}
							}
						}
					}
				}
			}
		}
		
		//this is for the case between the start entity and the from entity (there maybe mor than one relationships)
		if (paths== null || paths.size() == 0)
		{
			for (String temp: tempPaths)
			{
				finalPaths.add(temp);
			}
		}
		
		//this is for any path between a from and a to entity...
		for (String path: paths)
		{
			for (String temp: tempPaths)
			{
				finalPaths.add(path + "\n" + AND + "\n" + temp);
			}
		}
		
		return finalPaths;
	}

	
	//Create a path name for the GUI representation, i.e. a concat string that shows the name of the
	//EntityFrom, the name of the Relationship and the name of the EntityTo
	public static String getPathName(String entityFromName, String relationshipName, String entityToName)
	{
		return entityFromName + " |- " + relationshipName + " -| " + entityToName;
	}
	
	//Gets the EntityFrom name from the UI path
	public static String getFromEntityName(String pathName)
	{
		if (pathName != "")
			return pathName.split(" |- ")[0];
		
		return "";
	}
	
	//Gets the EntityTo name from the UI path
	public static String getToEntityName(String pathName)
	{
		if (pathName != "")
			return pathName.split(" |- ")[4];
		
		return "";
	}
	
	//Gets the Relationship name from the UI path
	public static String getRelationshipName(String pathName)
	{
		if (pathName != "")
			return  pathName.split(" |- ")[2];
		
		return "";
	}
	
	
	private static String NO_PATH_REMOVE = "No Path removed";
	private static String AND =  " And ";
}
