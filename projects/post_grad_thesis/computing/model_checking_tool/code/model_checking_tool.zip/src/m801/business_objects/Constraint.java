package m801.business_objects;

//This class represents the constraint object
public class Constraint 
{
	//The constructor
	public Constraint()
	{
		_from = null;
		_to =null;
		_type = Enum.ConstraintType.INCLUSION.toString(); 
	}
	
	//Create the constraint name
	public static String createName(String entityFrom, String entityTo)
	{
		return entityFrom + "-" + entityTo;
	}
	
	//Get the constraint name
	public String getName()
	{
		return createName(_from.getEntityName(), _to.getEntityName());
	}
	
	//Set the fromEntity
	public void setFrom(ConstraintEnd constraintEnd)
	{
		_from = constraintEnd;
	}
	
	//Get the fromEntity
	public ConstraintEnd getFrom()
	{
		return _from;
	}
	
	//Set the to entity
	public void setTo(ConstraintEnd constraintEnd)
	{
		_to = constraintEnd;
	}
	
	//Get the toEntity
	public ConstraintEnd getTo()
	{
		return _to;
	}
	
	//Constraint object to String
	public String toString()
	{
		return "Constraint " + "type " + _type + 
				" name " +  createName(_from.getEntityName(), _to.getEntityName()) +
				"ConstraintEnd from=" + _from.getEntityName() + " " +
				"attributes=" + _from.getAttributesToString() + " " +
				"ConstraintEnd to=" + _to.getEntityName() + " " +
				"attributes=" + _to.getAttributesToString() + " ";
	}
	
	//Check whether the constrain between entities are the same 
	public boolean contentEquals(CharSequence cs)
	{
		if (createName(_from.getEntityName(), _to.getEntityName()).contains(cs) == true ||
			createName(_to.getEntityName(), _from.getEntityName()).contentEquals(cs) == true)
		{
			return true;
		}
		return false;
	}
	
	private ConstraintEnd _from;
	private ConstraintEnd _to;
	private String _type;

}

