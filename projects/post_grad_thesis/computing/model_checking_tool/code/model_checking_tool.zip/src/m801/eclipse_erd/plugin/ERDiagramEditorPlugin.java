package m801.eclipse_erd.plugin;

import java.util.MissingResourceException;
import java.util.ResourceBundle;

import org.eclipse.core.resources.IWorkspace;
import org.eclipse.core.resources.ResourcesPlugin;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Platform;
import org.eclipse.core.runtime.Status;
import org.eclipse.ui.plugin.AbstractUIPlugin;

/**
 * This is our Plugin class that will implement a singleton to give back
 * informations that are used generally. It also implements a method to give
 * back resources inside of this plugin.
 * 
 * $Id: ERDiagramEditorPlugin.java,v 1.14 2005/10/24 04:51:50 ricosoft Exp $
 */
public class ERDiagramEditorPlugin extends AbstractUIPlugin {
	public static final String PLUGIN_ID = "ER Diagram Plugin";

	/**
	 * static variable for the plugin.
	 */
	private static ERDiagramEditorPlugin plugin;

	/**
	 * static variable for our resource bundle for this plugin.
	 */
	public static ResourceBundle resourceBundle;

	/**
	 * return the resource bundle for our plugin or null if it can't be loaded.
	 * 
	 * @return resource bundle of our project.
	 */
	public static ResourceBundle getResourceBundle() {
		if (null == resourceBundle) {
			try {
				resourceBundle = ResourceBundle
						.getBundle(ERDiagramEditorPlugin.class.getName());
			} catch (MissingResourceException e) {
				resourceBundle = null;
			}
		}
		return resourceBundle;
	}

	/**
	 * return the string in the resource bundle corresponding to the given key.
	 * if the key is not found the key will be returned itself instead.
	 * 
	 * @return the string that corresponds to the key or the key itself
	 */
	public static String getResourceString(String key) {
		ResourceBundle bundle = getResourceBundle();

		if (null == bundle) {
			return key;
		}

		try {
			return bundle.getString(key);
		} catch (MissingResourceException e) {
			return key;
		}
	}

	/**
	 * the workspace corresponding to the given plugin.
	 * 
	 * @return the workspace to the given object.
	 */
	public static IWorkspace getWorkspace() {
		return ResourcesPlugin.getWorkspace();
	}

	/**
	 * the constructor for our plugin.
	 */
	public ERDiagramEditorPlugin() {
		super();
		plugin = this;
	}

	/**
	 * This just returns our plugin instance.
	 * 
	 * @return the plugin instance.
	 */
	public static ERDiagramEditorPlugin getDefault() {
		return plugin;
	}

	/**
	 * Log the given message.
	 * 
	 * @param severity
	 *            the severity of the message
	 * @param message
	 *            the message
	 * @param ex
	 *            an exception or <code>null</code>
	 * @see IStatus#getSeverity()
	 * @see IStatus#getMessage()
	 * @see IStatus#getException()
	 */
	public static void log(int severity, String message, Exception ex) {
		Platform.getLog(Platform.getBundle(PLUGIN_ID)).log(
				new Status(severity, PLUGIN_ID, IStatus.OK, message, ex));
	}

}
