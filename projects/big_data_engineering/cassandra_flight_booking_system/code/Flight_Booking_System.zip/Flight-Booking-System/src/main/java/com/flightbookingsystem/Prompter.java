package com.flightbookingsystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.query.QueryResult;

public class Prompter 
{
	//Get the operation the user wants to perform with the booking system
	public static String wannaBookWithUs() throws IOException
	{
		StringBuilder sb = new StringBuilder();
		sb.append("Welcome to the Casssandra Flight Booking System!");
		sb.append("\r");
		sb.append("1. Make a Booking / 2. Check Bookings / 9. Exit Booking (Enter [1] [2] or [9])");
		return askQestion(sb.toString());
	}
	
	//Get the departure date 
	public static String getTravelDate(String direction) throws IOException
	{
		return askQestion(direction + " Date:");
	}
	
	//Ask qny question to the user and return the answer 
	public static String askQestion(String question) throws IOException
	{
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
        printShortQuestion(question);
        String response = bf.readLine();
        
        return response;
	}
	
	//Get the travel information from the user
	public static String getTravelFlightAita(QueryResult<Rows<String, String, String>>  queryResult, String direction ) throws IOException
	{
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		
		printLongQuestion("This is the list of available " + direction + " times & prices:");
        ReportFormatter.display2(queryResult, false);
        
        printShortQuestion("Select Flight Details (" + direction +")");
        String aita = bf.readLine();
		
		return  aita;
	}
	
	//Get the booking information from the user
	public static ArrayList<String> getBookingInput() throws IOException
	{
		BufferedReader bf = new BufferedReader(new InputStreamReader(System.in));
		ArrayList<String>  bookingDetails = new ArrayList<String>();
		
		printLongQuestion("1. View all bookings / 2. View filtered Bookings (Enter [1] or [2])");
		String response = bf.readLine();
		
		if (response.toString().toUpperCase().equals("2")){
			printLongQuestion("Filter by: 1. Credit Card Details / 2. Booking Id / 3. Group Id (Enter [1], [2] or [3])");
			response = bf.readLine();
			if (response.toString().toUpperCase().equals("1")){
				printShortQuestion("Credit Card Details:");
				response = bf.readLine();
				bookingDetails.add(BookingDetailsEnum.CREDIT_CARD.toString());
				bookingDetails.add(response);
			}
			else if (response.toString().toUpperCase().equals("2")){
				printShortQuestion("Booking Id:");
				response = bf.readLine();
				bookingDetails.add(BookingDetailsEnum.BOOKING_ID.toString());
				bookingDetails.add(response);
			}
			else{
				printShortQuestion("Group Id:");
				response = bf.readLine();
				bookingDetails.add(BookingDetailsEnum.GROUP_ID.toString());
				bookingDetails.add(response);
			}
		}
		else{
			bookingDetails.add(BookingDetailsEnum.ALL.toString());
			bookingDetails.add("");
		}

		return  bookingDetails;
	}
	
	private static void printLongQuestion(String msg){
        System.out.println("**********************************************");
        System.out.println(msg);
		System.out.println("**********************************************");
	}
	
	private static void printShortQuestion(String msg){
		System.out.println("**************");
        System.out.println(msg);
        System.out.println("**************");
	}
}
	