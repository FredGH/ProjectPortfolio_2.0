package com.flightbookingsystem;

import java.util.UUID;

import me.prettyprint.cassandra.model.CqlQuery;
import me.prettyprint.cassandra.model.CqlRows;
import me.prettyprint.cassandra.serializers.StringSerializer;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.query.QueryResult;

public class CassandraDalCqlService {
	
	private static final StringSerializer SE = StringSerializer.get();
	private Keyspace keyspaceOperator;
	
	CassandraDalCqlService(Keyspace keyspaceOperator){
		this.keyspaceOperator = keyspaceOperator;
	}
	 
	public void dropBookingsTable(){
		Utilities.msgStart("dropBookingsTable");
		
		String query= "DROP COLUMNFAMILY bookings";
		executeQuery(query);
		
		Utilities.msgEnd("dropBookingsTable");
	}
	
	public void createBookingsTable(){
		Utilities.msgStart("createBookingsTable");
		
	     String query= "CREATE COLUMNFAMILY bookings (booking_id varchar PRIMARY KEY,group_id varchar,departure_details varchar,arrival_details varchar,passenger_details varchar,credit_card_details varchar,price varchar)\n" +
 		       "        WITH comparator = UTF8Type AND default_validation=UTF8Type";
	     executeQuery(query);
	     
	     Utilities.msgEnd("createBookingsTable");
	}
	
	public void createBookingsIndexes(){
		Utilities.msgStart("createBookingsIndexes");

		String query;
		String part = "CREATE INDEX ON bookings ";

		query = part + "(group_id)";
		executeQuery(query);
		
		query = part + "(credit_card_details)";
		executeQuery(query);
		
		Utilities.msgEnd("createBookingsIndexes");
	}
	
	public void saveBookings(){
		Utilities.msgStart("saveBookingsTable");
		
		String query;
		String part = "INSERT INTO bookings (booking_id,group_id, departure_details, arrival_details, passenger_details,credit_card_details, price) VALUES ";

		query = part + "('1', '1', 'ORY,Paris-Orly,Paris,France,28-Aug-2016 18:00:00', 'LHR,London Heathrow,London,United Kingdom,30-Aug-2016 19:00:00','John,McKay','AMEX,1234', '100.00')";
		executeQuery(query);

		query = part + "('2','1','ORY,Paris-Orly,Paris,France,28-Aug-2016 18:00:00','LHR,London Heathrow,London,United Kingdom,30-Aug-2016 19:00:00','Peter,Jones','AMEX,2569', '100.00')";
		executeQuery(query);
		
		query = part + "('3','1','ORY,Paris-Orly,Paris,France,28-Aug-2016 18:00:00','LHR,London Heathrow,London,United Kingdom,30-Aug-2016 19:00:00','Adam,Rodhes','AMEX,2569', '100.00')";
		executeQuery(query);
		
		Utilities.msgEnd("saveBookingsTable");
	}
	
	public void saveBookings(String inboundDetails, String outboundDetails, String passengerNameDetails, String creditCardDetails){
		Utilities.msgStart("saveBookingsTable");
		
		String departtureAirport = "LHR,London Heathrow,London,United Kingdom";
		String arrivalAirport = "ORY,Paris-Orly,Paris,France";
		//no checks... I'm courageous...
		Double inboundPrice = Double.parseDouble(inboundDetails.split(",")[2]);
		Double outboundPrice = Double.parseDouble(inboundDetails.split(",")[2]);
		String totalPrice = Double.toString((inboundPrice + outboundPrice));
		
		String query;
		String part = "INSERT INTO bookings (booking_id,group_id, departure_details, arrival_details, passenger_details,credit_card_details, price) VALUES ";

		query = part + "(" + "'" + UUID.randomUUID().toString() + "'," + 
						 	 "'" + UUID.randomUUID().toString() + "'," +
						 	 "'" + departtureAirport +  " to " + arrivalAirport + ", " + inboundDetails  + "',"  + 
						 	 "'" + arrivalAirport +  " to " + departtureAirport + ", " + outboundDetails + "',"  + 
						 	 "'" + passengerNameDetails + "'," +
						 	 "'" + creditCardDetails + "',"  +
						 	 "'" + totalPrice + "')"; 
		executeQuery(query);
		
		Utilities.msgEnd("saveBookingsTable");
	}
	
	public QueryResult<CqlRows<String, String, String>>  getFromBookingsTable(){
		return getFromBookingsTable(null);
	}
	
	public QueryResult<CqlRows<String, String, String>>  getFromBookingsTable(String condition){
		Utilities.msgStart("SelectFromBookingsTable");
		
		String query; 
		String part = "SELECT booking_id,group_id, departure_details, arrival_details, passenger_details,credit_card_details, price FROM bookings";
		if (condition != null){
			query = part + " WHERE " + condition;
		}
		else{
			query = part;
		}
		
		Utilities.msgEnd(query);
		QueryResult<CqlRows<String, String, String>> res = executeQuery(query);

		Utilities.msgEnd("SelectFromBookingsTable");
		
		return res;
	}
	
	public void dropAirportsTable(){
		Utilities.msgStart("dropAirportsTable");
		
		String query= "DROP COLUMNFAMILY airports";
		executeQuery(query);
		
		Utilities.msgEnd("dropAirportsTable");
	}
	
	public void createAirportsTable(){
		Utilities.msgStart("createAirportsTable");
		
	     String query= "CREATE COLUMNFAMILY airports (iata varchar PRIMARY KEY,name varchar,city varchar,country varchar)\n" +
 		       "        WITH comparator = UTF8Type AND default_validation=UTF8Type";
	     executeQuery(query);
	     
	     Utilities.msgEnd("createAirportsTable");
	}

	public void saveAirports(){
		Utilities.msgStart("saveAirportsTable");
		
		String query;
		String part = "INSERT INTO airports (iata, name, city, country) VALUES ";

		query = part + "('LHR','London Heathrow','London','United Kingdom')";
		executeQuery(query);
		
		query = part + "('FJK','John F Kennedy International','New York','United States')";
		executeQuery(query);
		
		Utilities.msgEnd("saveAirportsTable");
	}
	
	private QueryResult<CqlRows<String, String, String>>  executeQuery(String query){
		CqlQuery<String,String,String> cqlQuery = new CqlQuery<String,String,String>(keyspaceOperator, SE, SE, SE);
	    cqlQuery.setQuery(query);
	    QueryResult<CqlRows<String, String, String>> result = cqlQuery.execute();
	    return result;
	}
	
}
