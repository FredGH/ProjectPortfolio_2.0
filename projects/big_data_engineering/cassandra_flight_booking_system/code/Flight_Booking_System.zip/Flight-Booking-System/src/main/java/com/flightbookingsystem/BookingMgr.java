package com.flightbookingsystem;

import java.io.IOException;
import java.util.ArrayList;

import me.prettyprint.cassandra.model.CqlRows;
import me.prettyprint.hector.api.Cluster;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.ddl.ColumnFamilyDefinition;
import me.prettyprint.hector.api.factory.HFactory;
import me.prettyprint.hector.api.query.QueryResult;

public class BookingMgr {
	 
	private static CassandraDalCqlService cassandraDalCqlSvc;
	private static CassandraDalThriftService cassandraDalThriftSvc;
	private static final String KEYSPACE = "flight_booking_db";
	
	public static void main(String args []) throws IOException, InterruptedException{

		//Create the cluster or simply connect to it if already exist
		Cluster cluster = HFactory.getOrCreateCluster("datastax_demo","localhost:9160");
		
		try {
			//Create the list of Column Family definitions 
			//This used by thrift for CRUD operations / not used by CQL direct execution	
			ArrayList<ColumnFamilyDefinition> colDefs = 
					CassandraDalThriftService.generateColumnFamilyDefinitions(KEYSPACE);

			//Create the keyspace if it does not already exist
	        KeyspaceManager keyspaceManager = new KeyspaceManager(cluster,KEYSPACE, colDefs);
	        
	        Keyspace keyspaceOperator = keyspaceManager.createKeyspaceOperator();
	        
	        //Instantiate the services 
	        cassandraDalCqlSvc = new CassandraDalCqlService (keyspaceOperator);
	        cassandraDalThriftSvc = new CassandraDalThriftService (cluster, KEYSPACE, keyspaceOperator);

	        //Create schemas calling CQL directly 
	        //And load the predefined data
	        createCQLSchemas();
	        preloadCQLSchemas();
	        
	        //Load data using the thrift interface
	        preloadThriftSchemas();
	        
			//Execute the booking system
			run(cluster, keyspaceOperator);
			
			//Sleep for 3 seconds and shut the app down.
			Thread.sleep(3000); 
			System.exit(1);
		}
		catch (IOException  ioe) {System.err.println("IOException: " + ioe.getMessage());}
		catch (InterruptedException ie) {System.err.println("InterruptedException: " + ie.getMessage());}
		catch (Exception e) {System.err.println("Exception: " + e.getMessage());}
		finally{cluster.getConnectionManager().shutdown();}
	 }
	
	private static void createCQLSchemas(){
        cassandraDalCqlSvc.createBookingsTable();
        cassandraDalCqlSvc.createBookingsIndexes();
        cassandraDalCqlSvc.createAirportsTable();
	}
	
	private static void preloadCQLSchemas(){
		cassandraDalCqlSvc.saveBookings();
        cassandraDalCqlSvc.saveAirports();
	}
	
	private static void preloadThriftSchemas(){
		cassandraDalThriftSvc.saveFlightDetails();
	}
	
	private static void run(Cluster cluster,Keyspace keyspaceOperator) throws Exception{
		//Ask the user whether to continue with the booking
		String response = Prompter.wannaBookWithUs();
		
		//Make a booking
		if (response.toString().toUpperCase().equals("1")){

	        String inFlightDetails = getFlightDetails("Inbound");
	        String outFlightDetails = getFlightDetails("Outbound");
	        
	        String passengerNameDetails = Prompter.askQestion("Passenger [First Name,Last Name]");
	        String creditCardDetails = Prompter.askQestion("Credit Card Details [Type,Long Number]");
	        
	        cassandraDalCqlSvc.saveBookings(inFlightDetails, outFlightDetails, passengerNameDetails, creditCardDetails);
        
	        //Save the travel plan into the booking area
	        run(cluster, keyspaceOperator);
		}
		//View existing bookings
		else if (response.toString().toUpperCase().equals("2")){
			ArrayList<String> bookingDetails = Prompter.getBookingInput();
			String bookingType = bookingDetails.get(0);
 
			if (bookingType.equals(BookingDetailsEnum.ALL.toString())){
				//Get all list of bookings from cassandra
				QueryResult<CqlRows<String, String, String>> queryResult = cassandraDalCqlSvc.getFromBookingsTable();
				//Print to screen
				ReportFormatter.display(queryResult, true);
				run(cluster, keyspaceOperator);
			}
			else if (bookingType.equals(BookingDetailsEnum.CREDIT_CARD.toString())){
				String creditCardDetails = bookingDetails.get(1);
				FetchAndPrint (cluster, keyspaceOperator, "credit_card_details = '" + creditCardDetails + "'");
			}
			else if (bookingType.equals(BookingDetailsEnum.BOOKING_ID.toString())){
				String bookingId = bookingDetails.get(1);
				FetchAndPrint (cluster, keyspaceOperator, "booking_id = '" + bookingId + "'");
			}
			else if (bookingType.equals(BookingDetailsEnum.GROUP_ID.toString())){
				String groupId = bookingDetails.get(1);
				FetchAndPrint (cluster, keyspaceOperator, "group_id = '" + groupId + "'");
			}
			else{
				throw new Exception("BookingDetailsEnum not recognised:" + bookingType ); 
			}
		}
		//Goodbye
		else if (response.toString().toUpperCase().equals("9")){
			System.out.println("See later and enjoy you day... ;-)");
		}
		//Error
		else {
			System.out.println("Incorrect Entry");
			//Sleep for 2 seconds and shut the app down.
			Thread.sleep(2000);
			//Start again...
			run(cluster, keyspaceOperator);
		}
	}
	
	private static void FetchAndPrint(Cluster cluster,Keyspace keyspace, String condition) throws Exception{
		QueryResult<CqlRows<String, String, String>> queryResult = cassandraDalCqlSvc.getFromBookingsTable(condition);
		//Print to screen
		ReportFormatter.display(queryResult, true);
		run(cluster, keyspace);
	}
	
	private static String getFlightDetails(String direction) throws IOException
	{
		//Ask for the departure date
		String departureDate = Prompter.getTravelDate(direction);
		//Get the list of flights for that date
		QueryResult<Rows<String, String, String>>  queryResult = cassandraDalThriftSvc.getFlightDetails(departureDate);
        //Ask for the chosen departure date 
        String flightDetails = Prompter.getTravelFlightAita(queryResult, direction);
        
        return flightDetails;
	}
}






