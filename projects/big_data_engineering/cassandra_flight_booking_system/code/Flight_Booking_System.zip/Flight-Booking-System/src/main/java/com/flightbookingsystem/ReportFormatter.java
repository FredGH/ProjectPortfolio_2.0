package com.flightbookingsystem;

import java.util.ArrayList;
import java.util.List;

import me.prettyprint.cassandra.model.CqlRows;
import me.prettyprint.hector.api.beans.ColumnSlice;
import me.prettyprint.hector.api.beans.HColumn;
import me.prettyprint.hector.api.beans.Row;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.query.QueryResult;

public class ReportFormatter {
	
	
	
	
	public static void display(QueryResult<CqlRows<String, String, String>> queryResult, Boolean horizontal){
		if (queryResult!=null){
			List<Row<String,String,String>> rows = queryResult.get().getList();
			display(rows, horizontal);
		 }
		else{
			System.out.println("No Data Available");
		}
	}
	
	public static void display2(QueryResult<Rows<String, String, String>> queryResult, Boolean horizontal){
		if (queryResult!=null){
			Rows<String,String,String> rows = queryResult.get();
			ArrayList<Row<String, String, String>> rowList = new ArrayList<Row<String, String, String>>();
			for (Row<String, String, String> row:rows){
				rowList.add(row);
			}
			display(rowList, horizontal);
		 }
		else{
			System.out.println("No Data Available");
		}
	}

	private static void display(List<Row<String, String, String>> rows, Boolean horizontal){
		StringBuilder sb = new StringBuilder();
		if (rows !=null ){
			 for (Row<String, String, String> row:rows){
				 ColumnSlice<String, String> columnSlice =  row.getColumnSlice();
				 for (HColumn<String, String> column:columnSlice.getColumns()){
				 	 sb.append(column.getName()+ ": " + column.getValue());
				 	 if (horizontal){
				 		 sb.append(" / ");
				 	 }
				 	 else{
				 		sb.append("\n");
				 	 }
				 }
				 sb.append("\n");
			 }
		}
		sb.deleteCharAt(sb.length()-1);
		System.out.println("\n");
		System.out.println(">>>>>>>>>>>>>>>>Start Query Result>>>>>>>>>>>>>>>>>>>>>>>");
		System.out.println(sb.toString() );
		System.out.println(">>>>>>>>>>>>>>>>End Query Result>>>>>>>>>>>>>>>>>>>>>>>");
		System.out.println("\n");
	}

}
