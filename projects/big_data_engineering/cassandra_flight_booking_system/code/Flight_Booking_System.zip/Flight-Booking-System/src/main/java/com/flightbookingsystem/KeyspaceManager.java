package com.flightbookingsystem;

import java.util.ArrayList;
import me.prettyprint.cassandra.service.ThriftKsDef;
import me.prettyprint.hector.api.Cluster;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.ddl.ColumnFamilyDefinition;
import me.prettyprint.hector.api.ddl.KeyspaceDefinition;
import me.prettyprint.hector.api.factory.HFactory;

public class KeyspaceManager {
	
	private Cluster cluster; 
	private String keyspace;
	private ArrayList<ColumnFamilyDefinition> cfDefs;
	
	public KeyspaceManager(Cluster cluster, String keyspace, ArrayList<ColumnFamilyDefinition> cfDefs )
	{
		this.cluster = cluster;
		this.keyspace = keyspace;
		this.cfDefs = cfDefs;
	}

	public Keyspace createKeyspaceOperator() 
	{
        KeyspaceDefinition keyspaceDefinition = HFactory.createKeyspaceDefinition(keyspace, ThriftKsDef.DEF_STRATEGY_CLASS,  1, cfDefs);
        cluster.addKeyspace(keyspaceDefinition, true);
        
        /*ConfigurableConsistencyLevel cfgCLevel = new ConfigurableConsistencyLevel(); 
        Map<String, HConsistencyLevel>   clmap = new HashMap<String, HConsistencyLevel>();
        clmap.put("FlightDetails", HConsistencyLevel.ONE);
        cfgCLevel.setReadCfConsistencyLevels(clmap);
        cfgCLevel.setWriteCfConsistencyLevels(clmap);*/
        Keyspace keyspaceOperator = HFactory.createKeyspace(keyspace, cluster/*, cfgCLevel*/);
        
        return keyspaceOperator;
	}
}
