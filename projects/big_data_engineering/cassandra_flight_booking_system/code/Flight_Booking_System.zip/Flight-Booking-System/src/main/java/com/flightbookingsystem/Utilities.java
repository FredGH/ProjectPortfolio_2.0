package com.flightbookingsystem;

public class Utilities {

	public static void msgStart(String msg)
	{
		System.out.println("Start -> " + msg);
	}
	
	public static void msgEnd(String msg)
	{
		System.out.println("End -> " + msg);
	}
}
