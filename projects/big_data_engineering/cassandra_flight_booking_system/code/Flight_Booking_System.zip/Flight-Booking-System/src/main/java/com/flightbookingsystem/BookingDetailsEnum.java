package com.flightbookingsystem;

public enum BookingDetailsEnum {
	ALL,
	CREDIT_CARD,
	BOOKING_ID,
	GROUP_ID
}

