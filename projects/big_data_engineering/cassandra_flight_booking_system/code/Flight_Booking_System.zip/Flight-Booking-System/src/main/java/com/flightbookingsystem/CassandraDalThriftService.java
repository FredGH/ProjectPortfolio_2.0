package com.flightbookingsystem;

import java.util.ArrayList;

import me.prettyprint.cassandra.serializers.StringSerializer;
import me.prettyprint.hector.api.Cluster;
import me.prettyprint.hector.api.Keyspace;
import me.prettyprint.hector.api.beans.Rows;
import me.prettyprint.hector.api.ddl.ColumnFamilyDefinition;
import me.prettyprint.hector.api.ddl.ComparatorType;
import me.prettyprint.hector.api.factory.HFactory;
import me.prettyprint.hector.api.mutation.Mutator;
import me.prettyprint.hector.api.query.MultigetSliceQuery;
import me.prettyprint.hector.api.query.QueryResult;

public class CassandraDalThriftService {
	
	private static final StringSerializer SE = StringSerializer.get();
	private static ArrayList<ColumnFamilyDefinition> columnFamilyDefinitions = new ArrayList<ColumnFamilyDefinition>();
	private static final int ALL = Integer.MAX_VALUE;
	private Keyspace keyspaceOperator;
	
	public static final String FLIGHTDETAILS = "flight_details";
	
	public static ArrayList<ColumnFamilyDefinition> generateColumnFamilyDefinitions(String keyspace){
		columnFamilyDefinitions.add(createColumnFamilyDefinition(keyspace, FLIGHTDETAILS));
		return columnFamilyDefinitions;
	}
	
	public CassandraDalThriftService(Cluster cluster, String keyspace, Keyspace keyspaceOperator){
		this.keyspaceOperator = keyspaceOperator;
	}
	
	public void saveFlightDetails(){
		Utilities.msgStart("saveFlightDetails");
		
		Mutator<String>   mutator = HFactory.createMutator(keyspaceOperator, StringSerializer.get());
        mutator. addInsertion("30-Nov-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG366","12:00,15:00,17123"))
				.addInsertion("30-Nov-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E464",",,"))
				.addInsertion("30-Nov-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W462","09:00,10:00,25998"))
				.addInsertion("30-Nov-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q464","12:00,14:00,25998"))
				.addInsertion("30-Nov-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W664","13:00,14:00,25998"))
				.addInsertion("30-Nov-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F152","12:00,11:35,25998"))
				.addInsertion("01-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG367","13:00,16:00,17123"))
				.addInsertion("01-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E465",",,"))
				.addInsertion("01-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W463","10:00,11:00,25998"))
				.addInsertion("01-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q465","13:00,15:00,25998"))
				.addInsertion("01-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W665","14:00,15:00,25998"))
				.addInsertion("01-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F153","13:00,12:35,25998"))
				.addInsertion("02-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG368","14:00,17:00,17123"))
				.addInsertion("02-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E466",",,"))
				.addInsertion("02-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W464","11:00,12:00,25998"))
				.addInsertion("02-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q466","14:00,16:00,25998"))
				.addInsertion("02-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W666","15:00,16:00,25998"))
				.addInsertion("02-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F154","14:00,13:35,25998"))
				.addInsertion("03-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG369","15:00,18:00,17123"))
				.addInsertion("03-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E467",",,"))
				.addInsertion("03-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W465","12:00,13:00,25998"))
				.addInsertion("03-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q467","15:00,17:00,25998"))
				.addInsertion("03-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W667","16:00,17:00,25998"))
				.addInsertion("03-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F155","15:00,14:35,25998"))
				.addInsertion("04-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG370","16:00,19:00,14558"))
				.addInsertion("04-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E468",",,"))
				.addInsertion("04-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W466","13:00,14:00,25998"))
				.addInsertion("04-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q468","16:00,18:00,25998"))
				.addInsertion("04-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W668","17:00,18:00,25998"))
				.addInsertion("04-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F156","16:00,15:35,25998"))
				.addInsertion("05-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG371","17:00,20:00,14558"))
				.addInsertion("05-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E469",",,"))
				.addInsertion("05-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W467","14:00,15:00,25998"))
				.addInsertion("05-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q469","17:00,19:00,25998"))
				.addInsertion("05-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W669","18:00,19:00,25998"))
				.addInsertion("05-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F157","17:00,16:35,25998"))
				.addInsertion("06-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG372","18:00,21:00,14558"))
				.addInsertion("06-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E470",",,"))
				.addInsertion("06-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W468","15:00,16:00,25998"))
				.addInsertion("06-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q470","18:00,20:00,25998"))
				.addInsertion("06-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W670","19:00,20:00,25998"))
				.addInsertion("06-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F158","18:00,17:35,25998"))
				.addInsertion("07-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG373","19:00,22:00,14558"))
				.addInsertion("07-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E471",",,"))
				.addInsertion("07-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W469","16:00,17:00,25998"))
				.addInsertion("07-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q471","19:00,21:00,25998"))
				.addInsertion("07-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W671","20:00,21:00,25998"))
				.addInsertion("07-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F159","19:00,18:35,25998"))
				.addInsertion("08-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG374","20:00,23:00,14558"))
				.addInsertion("08-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E472",",,"))
				.addInsertion("08-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W470","17:00,18:00,25998"))
				.addInsertion("08-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q472","20:00,22:00,25998"))
				.addInsertion("08-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W672","21:00,22:00,25998"))
				.addInsertion("08-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("8F160","20:00,19:35,25998"))
				.addInsertion("09-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG375","21:00,00:00,14558"))
				.addInsertion("09-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E473",",,"))
				.addInsertion("09-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W471","18:00,19:00,25998"))
				.addInsertion("09-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q473","21:00,23:00,25998"))
				.addInsertion("09-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W673","22:00,23:00,25998"))
				.addInsertion("10-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG376","22:00,01:00,14558"))
				.addInsertion("10-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E474",",,"))
				.addInsertion("10-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W472","19:00,20:00,25998"))
				.addInsertion("10-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q474","22:00,00:00,25998"))
				.addInsertion("10-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W674","00:00,03:00,25998"))
				.addInsertion("11-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG377","23:00,02:00,14558"))
				.addInsertion("11-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E475",",,"))
				.addInsertion("11-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W473","20:00,21:00,25998"))
				.addInsertion("11-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q475","23:00,01:00,25998"))
				.addInsertion("11-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W675","01:00,04:00,25998"))
				.addInsertion("12-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG378","01:00,02:00,14558"))
				.addInsertion("12-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E476",",,"))
				.addInsertion("12-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W474","21:00,22:00,25998"))
				.addInsertion("12-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q476","00:00,02:00,25998"))
				.addInsertion("12-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W676","02:00,05:00,25998"))
				.addInsertion("13-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG379","02:00,03:00,14558"))
				.addInsertion("13-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E477",",,"))
				.addInsertion("13-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W475","22:00,23:00,25998"))
				.addInsertion("13-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q477","01:00,03:00,25998"))
				.addInsertion("13-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W677","03:00,06:00,25998"))
				.addInsertion("14-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG380","03:00,04:00,14558"))
				.addInsertion("14-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E478",",,"))
				.addInsertion("14-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W476","06:00,08:00,25998"))
				.addInsertion("14-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q478","02:00,04:00,25998"))
				.addInsertion("14-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W678","04:00,07:00,25998"))
				.addInsertion("15-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG381","04:00,05:00,14558"))
				.addInsertion("15-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E479",",,"))
				.addInsertion("15-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W477","07:00,09:00,25998"))
				.addInsertion("15-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q479","03:00,05:00,25998"))
				.addInsertion("15-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W679","05:00,08:00,25998"))
				.addInsertion("16-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG382","05:00,06:00,14558"))
				.addInsertion("16-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E480",",,"))
				.addInsertion("16-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W478","08:00,10:00,25998"))
				.addInsertion("16-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q480","04:00,06:00,25998"))
				.addInsertion("16-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W680","06:00,09:00,25998"))
				.addInsertion("17-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG383","06:00,07:00,14558"))
				.addInsertion("17-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E481",",,"))
				.addInsertion("17-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W479","09:00,11:00,25998"))
				.addInsertion("17-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q481","05:00,07:00,25998"))
				.addInsertion("17-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W681","07:00,10:00,25998"))
				.addInsertion("18-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG384","07:00,08:00,14558"))
				.addInsertion("18-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E482",",,"))
				.addInsertion("18-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W480","10:00,12:00,25998"))
				.addInsertion("18-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q482","06:00,08:00,25998"))
				.addInsertion("18-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W682","08:00,11:00,25998"))
				.addInsertion("19-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG385","08:00,09:00,14558"))
				.addInsertion("19-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E483",",,"))
				.addInsertion("19-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W481","11:00,13:00,25998"))
				.addInsertion("19-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q483","07:00,09:00,25998"))
				.addInsertion("19-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W683","09:00,12:00,25998"))
				.addInsertion("20-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG386","09:00,10:00,14558"))
				.addInsertion("20-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E484",",,"))
				.addInsertion("20-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W482","12:00,14:00,25998"))
				.addInsertion("20-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q484","08:00,10:00,25998"))
				.addInsertion("20-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W684","10:00,13:00,25998"))
				.addInsertion("21-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG387","10:00,11:00,14558"))
				.addInsertion("21-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E485",",,"))
				.addInsertion("21-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W483","13:00,15:00,25998"))
				.addInsertion("21-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q485","09:00,11:00,25998"))
				.addInsertion("21-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W685","11:00,14:00,25998"))
				.addInsertion("22-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG388","11:00,12:00,14558"))
				.addInsertion("22-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E486",",,"))
				.addInsertion("22-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W484","14:00,16:00,25998"))
				.addInsertion("22-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q486","10:00,12:00,25998"))
				.addInsertion("22-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W686","12:00,15:00,25998"))
				.addInsertion("23-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG389","12:00,13:00,25998"))
				.addInsertion("23-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E487",",,"))
				.addInsertion("23-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W485","15:00,17:00,25998"))
				.addInsertion("23-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q487","11:00,13:00,25998"))
				.addInsertion("23-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W687","13:00,16:00,25998"))
				.addInsertion("24-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG390","13:00,14:00,25998"))
				.addInsertion("24-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E488",",,"))
				.addInsertion("24-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W486","16:00,18:00,25998"))
				.addInsertion("24-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q488","12:00,14:00,25998"))
				.addInsertion("24-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W688","14:00,17:00,25998"))
				.addInsertion("25-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG391","14:00,15:00,25998"))
				.addInsertion("25-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E489",",,"))
				.addInsertion("25-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W487","17:00,19:00,25998"))
				.addInsertion("25-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q489","13:00,15:00,25998"))
				.addInsertion("25-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W689","15:00,18:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG392","15:00,16:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E490",",,"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W488","18:00,20:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q490","14:00,16:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W690","16:00,19:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W488","18:00,20:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q490","14:00,16:00,25998"))
				.addInsertion("26-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W690","16:00,19:00,25998"))
				.addInsertion("27-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG393","16:00,17:00,25998"))
				.addInsertion("27-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E491",",,"))
				.addInsertion("27-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W489","19:00,21:00,25998"))
				.addInsertion("27-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q491","15:00,17:00,25998"))
				.addInsertion("27-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W691","17:00,20:00,25998"))
				.addInsertion("28-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG394","17:00,18:00,25998"))
				.addInsertion("28-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E492",",,"))
				.addInsertion("28-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W490","20:00,22:00,25998"))
				.addInsertion("28-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q492","16:00,18:00,25998"))
				.addInsertion("28-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W692","18:00,21:00,25998"))
				.addInsertion("29-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG395","18:00,19:00,25998"))
				.addInsertion("29-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E493",",,"))
				.addInsertion("29-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W491","21:00,23:00,25998"))
				.addInsertion("29-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q493","17:00,19:00,25998"))
				.addInsertion("29-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W693","19:00,22:00,25998"))
				.addInsertion("30-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG396","19:00,20:00,25998"))
				.addInsertion("30-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E494",",,"))
				.addInsertion("30-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W492","22:00,00:00,25998"))
				.addInsertion("30-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q494","18:00,20:00,25998"))
				.addInsertion("30-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W694","20:00,23:00,25998"))
				.addInsertion("31-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("SG397","20:00,21:00,25998"))
				.addInsertion("31-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6E495",",,"))
				.addInsertion("31-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("9W493","23:00,01:00,25998"))
				.addInsertion("31-Dec-2013", FLIGHTDETAILS, HFactory.createStringColumn("6Q495","19:00,21:00,25998"));
		        		
        mutator.execute();
        
        Utilities.msgEnd("saveFlightDetails");
	}
	
	public QueryResult<Rows<String, String, String>> getFlightDetails(String dateKey){
		 MultigetSliceQuery<String, String, String> multigetSliceQuery = 
				 HFactory.createMultigetSliceQuery(keyspaceOperator, SE, SE, SE)        
				 .setColumnFamily(FLIGHTDETAILS)  
	       		 .setKeys(dateKey)
	       		.setRange(null, null, true, ALL);
	     QueryResult<Rows<String, String, String>> result = multigetSliceQuery.execute();
        
        return result;
	}	
	
	private static ColumnFamilyDefinition createColumnFamilyDefinition(String keyspace, String columnFamily){
		ColumnFamilyDefinition cfDef = HFactory.createColumnFamilyDefinition(keyspace, columnFamily, ComparatorType.UTF8TYPE);
		return cfDef;
	}

}



